"""Issue the panel's basket through gabinet.gov.pl in a background task.

The panel's "Wystaw" button posts ``{pesel, items: [...]}``; this module turns it
into one Playwright run: patient -> /rp/nowy -> 19 steps -> "Wystaw receptę" ->
warning "Tak" -> next basket line, until gabinet shows the prescriptions list.
The run then signs the whole batch ("Podpisz i wyślij wszystkie" -> "Podpisz
certyfikatem e-ZLA") and stops on the e-ZLA password popup: only the doctor can
finish that signature, so the state becomes ``awaiting_sign`` and **the browser
stays open** -- the next "Wystaw" reuses the same logged-in window for the next
patient instead of asking for another mObywatel login.

Only one basket runs at a time (there is one browser and one doctor), and the
panel polls :meth:`BasketIssuer.status` for progress.
"""

from __future__ import annotations

import asyncio
import datetime
import logging
from contextlib import AsyncExitStack, suppress
from typing import Any

from automation import (
    PrescriptionForm,
    PrescriptionRequest,
    StepFailed,
    issue_basket,
    requests_from_payload,
    sign_and_send_all,
    signing_pending,
)
from browser import LOGIN_TIMEOUT_S, SessionAborted, open_session
from diagnostics import Recorder

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.datetime.now(datetime.UTC).astimezone().isoformat(timespec="seconds")

class BasketIssuer:
    """Runs one basket at a time and exposes its progress to the panel."""

    def __init__(
        self,
        *,
        keep_open: bool = False,
        idle_timeout_s: float = 3600.0,
        login_timeout_s: float = LOGIN_TIMEOUT_S,
    ) -> None:
        self.keep_open = keep_open
        """Leave the browser open even when a basket fails (inspection)."""
        self.idle_timeout_s = idle_timeout_s
        """Safety net: close the parked browser when nobody comes back."""
        self.login_timeout_s = login_timeout_s
        """How long the doctor gets to log in again when the session expires."""
        self._session_stack: AsyncExitStack | None = None
        self._session: Any = None
        self._idle_task: asyncio.Task[None] | None = None
        self._task: asyncio.Task[None] | None = None
        self._state = "idle"
        self._message = "Gotowy do wystawienia."
        self._done = 0
        self._total = 0
        self._results: list[dict[str, Any]] = []
        self._started_at: str | None = None
        self._finished_at: str | None = None
        self._artifacts: str | None = None

    @property
    def busy(self) -> bool:
        """True while a basket (or a kept-open browser) occupies the session."""
        return self._task is not None and not self._task.done()

    def status(self) -> dict[str, Any]:
        return {
            "state": self._state,
            "message": self._message,
            "done": self._done,
            "total": self._total,
            "results": list(self._results),
            "started_at": self._started_at,
            "finished_at": self._finished_at,
            "artifacts": self._artifacts,
            "keep_open": self.keep_open,
        }

    def start(self, payload: Any) -> dict[str, Any]:
        """Validate ``payload`` and launch it; raises PayloadError/RuntimeError."""
        if self.busy:
            raise RuntimeError("wystawianie już trwa")
        if self._idle_task is not None:
            self._idle_task.cancel()
            self._idle_task = None
        pesel, requests = requests_from_payload(payload)

        total = len(requests)
        self._state = "running"
        self._message = f"Wystawiam 1/{total}…"
        self._done = 0
        self._total = total
        self._results = []
        self._started_at = _now()
        self._finished_at = None
        self._artifacts = None
        self._task = asyncio.create_task(self._run(pesel, requests), name="basket-issuer")
        return self.status()

    async def _ensure_session(self) -> Any:
        """Return a live gabinet session, launched once and reused across baskets.

        Launching Firefox takes ~8 s and a fresh mObywatel login, so the window is
        kept between baskets: after a basket is parked on the e-ZLA popup, the next
        "Wystaw" only has to enter the new patient's PESEL in the same session.
        """
        if self._session is not None and not self._session.browser.is_connected():
            logger.info("browser is gone; relaunching")
            await self.aclose()
        if self._session is not None and self._session.page.is_closed():
            logger.info("the tab was closed; opening a fresh one in the same session")
            self._session.page = await self._session.context.new_page()
        if self._session is None:
            stack = AsyncExitStack()
            # allow_logged_out: an expired mObywatel session is not an error here
            # -- the doctor logs in in the window that opens and the run waits.
            self._session = await stack.enter_async_context(
                open_session(
                    allow_logged_out=True,
                    login_timeout_s=self.login_timeout_s,
                )
            )
            self._session_stack = stack
            logger.info("browser session ready")
        return self._session

    async def _close_when_idle(self, delay: float) -> None:
        while True:
            await asyncio.sleep(delay)
            page = getattr(self._session, "page", None) if self._session is not None else None
            if page is None or not await signing_pending(page):
                break
            # The doctor is still on the password popup: closing now would throw
            # the pending prescriptions away, so wait another round.
            logger.info("idle timeout hit while the doctor was signing; waiting again")
        logger.info("no basket for %.0f s; closing the browser", delay)
        self._message = "Gotowy do wystawienia (przeglądarka zamknięta po bezczynności)."
        await self.aclose()

    def _arm_idle_close(self) -> None:
        if self._idle_task is not None and not self._idle_task.done():
            self._idle_task.cancel()
            self._idle_task = None
        if self.idle_timeout_s <= 0:
            return  # 0 = keep the window until the next "Wystaw" or shutdown
        self._idle_task = asyncio.create_task(self._close_when_idle(self.idle_timeout_s))

    async def _keep_or_close(self, recorder: Recorder, reason: str) -> None:
        """Leave a failed run's window open for inspection only with --keep-open."""
        if not self.keep_open:
            await self.aclose()
            return
        recorder.note(f"{reason}; holding the browser open (--keep-open)")
        self._arm_idle_close()

    async def aclose(self) -> None:
        """Close the browser (idle timeout, shutdown, or after a failure)."""
        if self._idle_task is not None:
            self._idle_task.cancel()
            self._idle_task = None
        stack, self._session_stack = self._session_stack, None
        self._session = None
        if stack is not None:
            with suppress(Exception):
                await stack.aclose()

    # -- internals ---------------------------------------------------------

    def _on_item(self, done: int, total: int, form: PrescriptionForm) -> None:
        self._done = done
        self._message = (
            f"Wystawiono {done}/{total}, otwieram kolejną…" if done < total else f"Wystawiono {done}/{total}."
        )
        self._results.append(
            {
                "index": done,
                "ingredient": form.ingredient,
                "quantity": form.quantity,
                "unit": form.unit,
                "dosing": form.dosing_text,
                "issued_url": form.issued_url,
            }
        )
        logger.info("issued basket item %s/%s", done, total)

    def _await_login(self, recorder: Recorder) -> None:
        """Tell the panel that the doctor has to log in before we can continue."""
        self._state = "login"
        self._message = (
            "Sesja mObywatel wygasła — zaloguj się w otwartym oknie Firefox, "
            "a ja ruszę dalej."
        )
        recorder.note("expired session: waiting for the doctor to log in")
        logger.info("waiting for the doctor to log in through mObywatel")

    def _fail(self, message: str, recorder: Recorder) -> None:
        self._state = "error"
        self._message = message
        self._finished_at = _now()
        recorder.note(message)

    async def _run(self, pesel: str, requests: list[PrescriptionRequest]) -> None:
        recorder = Recorder("basket")
        self._artifacts = str(recorder.path)
        logger.info("basket with %s item(s); artifacts in %s", len(requests), recorder.path)
        try:
            gabinet = await self._ensure_session()
            # The saved gabinet session expires every few days.  The doctor cannot
            # refresh it from a terminal, so wait for him to log in in the Firefox
            # window that is already open instead of failing the basket.
            if await gabinet.ensure_logged_in(
                timeout_s=self.login_timeout_s,
                on_wait=lambda: self._await_login(recorder),
            ):
                recorder.note("the doctor logged in through mObywatel; continuing")
                self._state = "running"
                self._message = f"Zalogowano — wystawiam 1/{self._total}…"
            if await signing_pending(gabinet.page):
                # Previous basket was never signed and the doctor has already
                # started the next patient: the window is about to be navigated.
                recorder.note("previous e-ZLA popup was still open -- unsent prescriptions?")
                logger.warning("navigating away from an unfinished e-ZLA signature")
            forms = await issue_basket(
                pesel,
                requests,
                page=gabinet.page,
                recorder=recorder,
                on_item=self._on_item,
            )
            self._state = "signing"
            self._message = f"Podpisuję i wysyłam {len(forms)} recept(y)…"
            await sign_and_send_all(gabinet.page, recorder=recorder)

            # Parked, not finished: the doctor enters the certificate password in
            # this window, so it stays open (and logged in) for the next "Wystaw".
            self._state = "awaiting_sign"
            self._finished_at = _now()
            self._message = (
                f"Wystawiono {len(forms)} recept(y). Podpisz je w oknie gabinetu "
                "hasłem e-ZLA — okno zostaje otwarte dla następnego pacjenta."
            )
            recorder.note("parked on the e-ZLA popup; the browser stays open")
            self._arm_idle_close()
        except SessionAborted as error:
            self._fail(
                "Nie doczekałem się logowania przez mObywatel — kliknij „Wystaw” "
                f"i zaloguj się w oknie Firefox ({error}).",
                recorder,
            )
            await self._keep_or_close(recorder, "login timeout")
        except StepFailed as error:
            self._fail(f"Automatyzacja zatrzymała się: {error}", recorder)
            await self._keep_or_close(recorder, "failure")
        except asyncio.CancelledError:
            self._fail("Wystawianie przerwane.", recorder)
            await self.aclose()
            raise
        except Exception as error:
            logger.exception("basket failed")
            self._fail(f"Błąd wystawiania: {error}", recorder)
            await self._keep_or_close(recorder, "failure")
