"""Browser impersonation for gabinet.gov.pl.

The government panel sits behind an mObywatel login, which cannot be scripted
(and must not be).  The workaround is a one-time human handshake: Playwright
drives a real Firefox window, a person logs in through mObywatel, and the
resulting browser session -- cookies *and* localStorage, i.e. Playwright's
``storage_state`` -- is written to the XDG state directory.  Every later run
restores that file and only asks for a ``y`` confirmation, so no government
login is needed again until the session expires.

State lives at::

    $XDG_STATE_HOME/aspot-bot/session.json
    ~/.local/state/aspot-bot/session.json          # XDG_STATE_HOME unset

Usage::

    uv run python browser.py           # reuse saved session, else log in once
    uv run python browser.py login     # force a fresh mObywatel login
    uv run python browser.py status    # show where the session lives

Programmatically::

    from browser import open_session

    async with open_session() as gabinet:
        page = gabinet.page          # logged-in Firefox page
        await page.goto("https://gabinet.gov.pl/...")

The session file is written with owner-only permissions; it is as sensitive as
a password -- anybody holding it is logged in as you.
"""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
import os
import sys
import time
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from playwright.async_api import Browser, BrowserContext, Page, async_playwright

APP_NAME = "aspot-bot"
"""Name of the directory under the XDG state home."""

STATE_FILE = "session.json"
"""One file, one session: cookies + per-origin localStorage."""

START_URL = "https://gabinet.gov.pl/wizyta/nowy"
"""Where every run lands. gabinet redirects to the mObywatel login itself when
no valid session is present, so this is both the login entry point and the
page the bot actually needs."""

LOGIN_URL_MARKERS = ("zaloguj", "logowanie")
"""Path fragments that mean "still on the login page, not authenticated"."""


LOGIN_TIMEOUT_S = 1800.0
"""How long the doctor gets to finish the mObywatel handshake (30 minutes).

A saved session expires every few days.  The doctor answers that by logging in
again in the Firefox window that is already open -- he never types a command --
so the timeout is generous: he has to pick up his phone first."""

logger = logging.getLogger(__name__)


class SessionAborted(RuntimeError):
    """The human did not confirm (or stdin closed) -- nothing was saved."""


def state_dir() -> Path:
    """Return the per-user state directory for this app (XDG, Unix-only)."""
    raw = os.environ.get("XDG_STATE_HOME", "")
    base = Path(raw) if raw and Path(raw).is_absolute() else Path.home() / ".local" / "state"
    return base / APP_NAME


def state_path() -> Path:
    """Return the absolute path of the saved session file."""
    return state_dir() / STATE_FILE


def has_session() -> bool:
    """True when a session file exists and parses as JSON."""
    return load_state() is not None


def load_state() -> dict | None:
    """Read the saved session, or None if it is missing/unreadable."""
    path = state_path()
    try:
        with path.open(encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def url_looks_logged_in(page: Page) -> bool:
    """Cheap URL-only check: are we on gabinet and past the login screen?"""
    url = urlparse(page.url)
    if "gabinet.gov.pl" not in url.netloc:
        # login.gov.pl and friends are part of the handshake, not the panel.
        return False
    return not any(marker in url.path.casefold() for marker in LOGIN_URL_MARKERS)


async def is_logged_in(page: Page, *, timeout_ms: int = 10_000) -> bool:
    """Tell whether the gabinet session is authenticated.

    gabinet is an Angular SPA: ``/wizyta/nowy`` is served to anonymous visitors
    too and only *then* redirects to ``/zaloguj/uzytkownik``, so the URL alone
    lies for a few seconds.  Poll instead for the two pieces of chrome that only
    exist in one of the states: the 'Wyloguj' link (authenticated) and the
    'Zaloguj się' link (anonymous).
    """
    deadline = time.monotonic() + timeout_ms / 1000
    while True:
        if not url_looks_logged_in(page):
            return False
        marker = await _auth_marker(page)
        if marker is not None:
            return marker
        if time.monotonic() >= deadline:
            # The page never painted a marker: trust the URL rather than block.
            return url_looks_logged_in(page)
        await page.wait_for_timeout(250)


async def _auth_marker(page: Page) -> bool | None:
    """True=authenticated, False=anonymous, None=page still navigating."""
    try:
        if await page.get_by_text("Wyloguj", exact=True).count():
            return True
        if await page.get_by_text("Zaloguj się", exact=True).count():
            return False
    except Exception as error:  # noqa: BLE001 - the DOM is not queryable mid-navigation
        logger.debug("auth marker probe skipped: %s", error)
    return None


async def confirm(question: str) -> bool:
    """Ask a y/n question in the terminal; anything but an explicit yes is no."""
    try:
        answer = await asyncio.to_thread(input, f"{question} [y/N] ")
    except EOFError:
        return False
    return answer.strip().casefold() in {"y", "yes", "tak", "t"}


@dataclass(slots=True)
class Gabinet:
    """A live browser session on gabinet.gov.pl."""

    page: Page
    """The page the login happened on -- navigate, click and fill from here."""

    context: BrowserContext
    """The whole impersonated Firefox profile (all tabs share cookies)."""

    browser: Browser
    """The underlying Firefox process."""

    reused: bool
    """True when the session came from disk instead of a fresh login."""

    state_file: Path
    """Where :func:`save_state` wrote/read the session."""

    async def cookies(self):
        return await self.context.cookies()

    async def logged_in(self, *, timeout_ms: int = 10_000) -> bool:
        """Whether this session is still authenticated."""
        return await is_logged_in(self.page, timeout_ms=timeout_ms)

    async def save(self) -> Path:
        """Persist the current session (cookies rotate, so refresh the file)."""
        return await _persist(self.context)

    async def ensure_logged_in(
        self,
        *,
        timeout_s: float = LOGIN_TIMEOUT_S,
        on_wait: Callable[[], None] | None = None,
    ) -> bool:
        """Make sure the session is authenticated, letting the doctor log in.

        Saved sessions expire every few days.  Instead of failing with "session
        expired" (which the doctor cannot act on -- he does not use a terminal),
        the Firefox window is left on the mObywatel login page and we wait for
        him to finish.  Returns True when it actually had to wait.
        """
        if await self.logged_in(timeout_ms=3_000):
            return False
        if on_wait is not None:
            on_wait()
        print(f"Session expired -- waiting for an mObywatel login on {self.page.url}", flush=True)
        with suppress(Exception):
            await self.page.goto(START_URL, wait_until="commit", timeout=60_000)
        await _wait_for_login(self.page, wait_timeout_s=timeout_s)
        await self.save()
        return True


async def _persist(context: BrowserContext) -> Path:
    """Write the context's storage state to the state dir with 0600 perms."""
    directory = state_dir()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = state_path()

    # Write-then-rename so an interrupted save cannot leave a torn JSON file
    # behind (which would silently mean "no session" on the next run).
    tmp = path.with_name(f".{STATE_FILE}.tmp")
    await context.storage_state(path=str(tmp))
    os.chmod(tmp, 0o600)
    tmp.replace(path)
    os.chmod(path, 0o600)
    return path


async def _wait_for_login(page: Page, *, wait_timeout_s: float = LOGIN_TIMEOUT_S) -> None:
    """Poll until a human finished the mObywatel handshake -- no keypress needed.

    The doctor only has to log in inside the Firefox window; we look for gabinet's
    own home screen ("Wyloguj" visible), because mObywatel still asks for the role
    and the place before it lands there.
    """
    deadline = time.monotonic() + wait_timeout_s
    last_note = time.monotonic()
    while time.monotonic() < deadline:
        on_home = urlparse(page.url).path.casefold().startswith("/strona-glowna")
        if on_home and await is_logged_in(page, timeout_ms=2_000):
            print("Logged in and on /strona-glowna -- saving the session.", flush=True)
            return
        if time.monotonic() - last_note > 20:
            last_note = time.monotonic()
            print(f"waiting for the login… ({page.url})", flush=True)
        await asyncio.sleep(1)
    raise SessionAborted(f"login did not complete within {wait_timeout_s:.0f} s")


async def _fresh_login(page: Page, *, wait_timeout_s: float = LOGIN_TIMEOUT_S) -> None:
    """Open the login page and wait for the human handshake (no saved session)."""
    print(
        f"\nA Firefox window is open on {START_URL} (it may redirect to the login page).\n"
        "  1. Log in there with mObywatel (profil zaufany / aplikacja mObywatel).\n"
        "  2. That is all -- the session is saved automatically once gabinet is up.\n"
        "The bot never sees your credentials -- only the resulting session.\n",
        flush=True,
    )
    await _wait_for_login(page, wait_timeout_s=wait_timeout_s)


@asynccontextmanager
async def open_session(
    *,
    force_login: bool = False,
    headless: bool = False,
    allow_logged_out: bool = False,
    login_timeout_s: float = LOGIN_TIMEOUT_S,
) -> AsyncIterator[Gabinet]:
    """Yield a Firefox session on gabinet.gov.pl.

    First run (or ``force_login=True``): opens :data:`START_URL` and waits for
    the human to log in with mObywatel, then saves the session.

    Later runs: restore ``$XDG_STATE_HOME/aspot-bot/session.json`` and reuse it
    silently.  With ``allow_logged_out=True`` an expired session is **not** an
    error: the browser is handed over as-is (sitting on the login page) and the
    caller awaits :meth:`Gabinet.ensure_logged_in`, so the doctor just logs in
    in the open window.  Without it, an expired session raises, which is what
    probes want.

    The session is re-saved on exit so rotated cookies survive into the next run.
    """
    path = state_path()
    saved = None if force_login else load_state()
    if saved is not None and not isinstance(saved.get("cookies"), list):
        saved = None  # not a storage_state file, ignore it

    if headless and saved is None:
        raise ValueError("a fresh mObywatel login needs a visible Firefox window")

    async with async_playwright() as playwright:
        try:
            browser = await playwright.firefox.launch(headless=headless)
        except Exception as error:
            if "executable" in str(error).casefold():
                raise RuntimeError(
                    "Firefox for Playwright is missing -- run: uv run playwright install firefox"
                ) from error
            raise

        context = await browser.new_context(
            storage_state=str(path) if saved is not None else None,
            locale="pl-PL",
            timezone_id="Europe/Warsaw",
        )
        page = context.pages[0] if context.pages else await context.new_page()

        try:
            await page.goto(START_URL, wait_until="domcontentloaded", timeout=60_000)

            reused = False
            if saved is not None:
                saved_at = _describe_mtime(path)
                cookie_count = len(saved.get("cookies", []))
                print(
                    f"Reusing the saved session ({cookie_count} cookies, saved {saved_at}).",
                    flush=True,
                )
                if not await is_logged_in(page, timeout_ms=15_000):
                    if not allow_logged_out:
                        raise RuntimeError(
                            "the saved gabinet session has expired -- "
                            "refresh it with: uv run python browser.py login"
                        )
                    print(
                        "The saved session has expired; leaving the login page open "
                        "for the doctor.",
                        flush=True,
                    )
                reused = True

            if not reused:
                await _fresh_login(page, wait_timeout_s=login_timeout_s)

            written = await _persist(context)
            count = len(await context.cookies())
            print(f"Session saved to {written} ({count} cookies, mode 600).\n", flush=True)

            session = Gabinet(
                page=page,
                context=context,
                browser=browser,
                reused=reused,
                state_file=written,
            )
            try:
                yield session
            finally:
                try:
                    if await context.cookies():
                        await _persist(context)
                except Exception as error:  # noqa: BLE001 - closing down; never mask the real error
                    print(f"warning: could not refresh the saved session: {error}", flush=True)
        finally:
            with suppress(Exception):
                await context.close()
            with suppress(Exception):
                await browser.close()


def _describe_mtime(path: Path) -> str:
    """Locally formatted mtime of the session file, for the confirmation prompt."""
    try:
        stamp = datetime.datetime.fromtimestamp(path.stat().st_mtime, tz=datetime.UTC).astimezone()
        return stamp.strftime("%Y-%m-%d %H:%M %Z")
    except OSError:
        return "unknown"


def status() -> int:
    """Print where the session lives and whether it is usable."""
    path = state_path()
    saved = load_state()
    print(f"app:      {APP_NAME}")
    print(f"state dir: {state_dir()}")
    print(f"session:  {path}")
    if saved is None:
        print("status:   no saved session (the next run will ask for a login)")
        return 1
    cookies = len(saved.get("cookies", []))
    origins = len(saved.get("origins", []))
    try:
        size = path.stat().st_size
        mode = oct(path.stat().st_mode & 0o777)
    except OSError:
        size, mode = 0, "?"
    print(f"status:   saved {_describe_mtime(path)} ({size} bytes, mode {mode})")
    print(f"contents: {cookies} cookies, {origins} localStorage origins")
    return 0


async def _run(force_login: bool) -> None:
    async with open_session(force_login=force_login) as gabinet:
        source = "saved session" if gabinet.reused else "fresh mObywatel login"
        print(f"Gabinet session ready ({source}). Logged in: {await gabinet.logged_in()}")



def main() -> None:
    command = sys.argv[1] if len(sys.argv) > 1 else "open"
    if command == "status":
        raise SystemExit(status())
    if command not in {"open", "login"}:
        print(__doc__)
        raise SystemExit(2)
    try:
        asyncio.run(_run(force_login=command == "login"))
    except (KeyboardInterrupt, SessionAborted) as error:
        reason = "interrupted" if isinstance(error, KeyboardInterrupt) else str(error)
        print(f"\nAborted ({reason}). No session was saved.", flush=True)
        raise SystemExit(130 if isinstance(error, KeyboardInterrupt) else 1) from error


if __name__ == "__main__":
    main()
