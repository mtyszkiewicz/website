"""Load the cannabis product Google Sheet into typed Python records.

Three things in the source sheet break the naive ``zip(headers, row)`` approach:

1. The header row is not row 1 -- every sheet starts with a title line, a
   "Wzory recept ..." subtitle, sometimes a warning line, and an empty row.
2. One product occupies *several* spreadsheet rows. Only the first row has the
   product columns filled in; the following rows only carry one more line of
   the prescription ("Wzór recepty"). Those continuation rows were being emitted
   as separate records full of ``None`` -- that is the "missing data".
3. ``iter_rows`` walks the whole formatted grid (1000 rows), so there is a tail
   of fully empty rows to skip.

Also: header names contain newlines, sheets are not consistent (Cantourage has
an extra row above the header), so headers are located dynamically and columns
are looked up by name instead of by position.

Each spreadsheet product becomes one :class:`CannabisProduct` record; each
worksheet becomes one :class:`ManufacturerSheet`.

The published sheet is the source of truth but not always reachable (offline,
Google quota, a 200 that is really a login page).  Every successful download is
persisted to ``sheet_snapshot.json`` next to this file, and a failed download
falls back to that snapshot, so the panel keeps working with the last known data
instead of refusing to boot.  ``python main.py --refresh-snapshot`` rewrites the
snapshot without starting the panel.

TODO(sheet -> panel): this parsed data is not served yet -- the panel ships its
own inlined ``CATALOG`` (``panel_receptowy_cannabis_flos_v2.html``) because the
sheet has no THC/CBD/genetics columns.  The plan is to enrich each row with
odmianymarihuany.pl data and then serve *that* to the panel, replacing the
inlined catalog.  Until then ``APP.state.sheets`` is informational only; do not
build UI on it.
"""

from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import sys
from contextlib import asynccontextmanager
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path

import requests
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from openpyxl import load_workbook

from automation import PayloadError
from diagnostics import configure_logging
from issuer import BasketIssuer

SHEET_ID = "1tBU9_ypMtenahM-QEWxuaq368dmk3XD3f6ms4adtdBM"
URL = f"https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=xlsx"

# Last good download, committed next to this file: the offline fallback.
SNAPSHOT_PATH = Path(__file__).with_name("sheet_snapshot.json")
SNAPSHOT_VERSION = 1

# Column headers in the sheet, normalised, mapped to descriptive field names.
HEADER_TO_FIELD = {
    "nazwa odmiany": "strain_name",
    "dostępność (terpenyedu)": "availability",
    "wielkość opakowania": "package_size",
    "nazwa na recepcie": "prescription_name",
    "charakterystyka odmiany": "characteristics",
}
RECIPE_HEADER = "wzór recepty"
PRODUCT_COL = "Nazwa odmiany"


@dataclass(frozen=True, slots=True)
class CannabisProduct:
    """One prescription record: a single variety / preparation on a sheet."""

    strain_name: str
    """'Nazwa odmiany' -- the variety as the pharmacy knows it."""

    availability: str
    """'Dostępność (terpenyedu)' -- 'Dostępna', 'Niedostępna', 'Brak w katalogu', ..."""

    package_size: str
    """'Wielkość opakowania' -- kept verbatim, e.g. '10G', '30ML', '25 ML (23,5 G)'."""

    prescription_name: str
    """'Nazwa na recepcie' -- the latin name written on the prescription."""

    prescription_lines: tuple[str, ...]
    """'Wzór recepty' -- the full template, one entry per spreadsheet row
    (first line is the heading, the rest are directions / dosing)."""

    characteristics: str
    """'Charakterystyka odmiany' -- catalogue link, PDF reference or free text."""

    manufacturer_sheet: str
    """Title of the worksheet this record came from, e.g. 'Aurora', 'S-LAB'."""

    source_rows: str
    """Spreadsheet row span this record was assembled from, e.g. '5-8'."""

    extra: tuple[tuple[str, str], ...] = ()
    """Any unmapped column that carried a value: (header, text) pairs."""

    @property
    def prescription(self) -> str:
        """The whole 'Wzór recepty' template as one text block."""
        return "\n".join(self.prescription_lines)

    @property
    def is_available(self) -> bool:
        """True only for an explicit 'Dostępna' ('Niedostępna' does not match)."""
        return self.availability.casefold().startswith("dostępna")

    @property
    def is_template(self) -> bool:
        """True for shared 'Wiele odmian ... pod jednym wzorem' template rows,
        which describe a group of varieties rather than a single one."""
        return self.availability.casefold().startswith("wspólny wzór")


@dataclass(frozen=True, slots=True)
class ManufacturerSheet:
    """One worksheet: the manufacturer's notes plus its product records."""

    title: str
    notes: tuple[str, ...]
    products: tuple[CannabisProduct, ...]

    def __len__(self) -> int:
        return len(self.products)

    def __iter__(self):
        return iter(self.products)

    def available(self) -> tuple[CannabisProduct, ...]:
        return tuple(p for p in self.products if p.is_available)


def norm(value) -> str:
    """Normalise a header/cell string: drop newlines, collapse spaces."""
    if value is None:
        return ""
    text = str(value).replace("\xa0", " ")
    return re.sub(r"\s+", " ", text).strip()


def norm_key(value) -> str:
    return norm(value).casefold().rstrip(":")


def blank(value) -> bool:
    return norm(value) == ""


def fetch_workbook(sheet_id: str = SHEET_ID, timeout: float = 30.0):
    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=xlsx"
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    return load_workbook(BytesIO(response.content), read_only=True, data_only=True)


def find_header_row(rows: list[tuple]) -> tuple[int, list[str]]:
    """Return (index, header names) of the first row that contains 'Nazwa odmiany'."""
    target = norm_key(PRODUCT_COL)
    for index, row in enumerate(rows):
        if any(norm_key(cell) == target for cell in row):
            return index, [norm(cell) for cell in row]

    # Fallback: first row that has 2+ non-empty cells.
    for index, row in enumerate(rows):
        if sum(1 for cell in row if not blank(cell)) >= 2:
            return index, [norm(cell) for cell in row]

    return -1, []


def _finish(builder: dict, sheet_title: str) -> CannabisProduct:
    """Turn one accumulated row-block into a record."""
    unknown = {
        header: text
        for header, text in builder["merged"].items()
        if norm_key(header) not in HEADER_TO_FIELD and norm_key(header) != RECIPE_HEADER
    }
    rows = builder["rows"]
    return CannabisProduct(
        strain_name=builder["fields"].get("strain_name", ""),
        availability=builder["fields"].get("availability", ""),
        package_size=builder["fields"].get("package_size", ""),
        prescription_name=builder["fields"].get("prescription_name", ""),
        prescription_lines=tuple(builder["lines"]),
        characteristics=builder["fields"].get("characteristics", ""),
        manufacturer_sheet=sheet_title,
        source_rows=f"{rows[0]}-{rows[-1]}" if len(rows) > 1 else str(rows[0]),
        extra=tuple(unknown.items()),
    )


def parse_sheet(rows: list[tuple], sheet_title: str) -> ManufacturerSheet:
    """Split one worksheet into preamble notes and product records."""
    header_index, headers = find_header_row(rows)
    if header_index < 0:
        return ManufacturerSheet(title=sheet_title, notes=(), products=())

    columns = {i: name for i, name in enumerate(headers) if name}
    product_idx = next((i for i, n in columns.items() if norm_key(n) == norm_key(PRODUCT_COL)), 0)
    recipe_idx = next((i for i, n in columns.items() if norm_key(n) == RECIPE_HEADER), None)

    notes = tuple(norm(row[0]) for row in rows[:header_index] if row and not blank(row[0]))

    builders: list[dict] = []
    current: dict | None = None

    def new_builder(row_number: int) -> dict:
        builder = {"fields": {}, "lines": [], "merged": {}, "rows": [row_number]}
        builders.append(builder)
        return builder

    for row_number, row in enumerate(rows[header_index + 1 :], start=header_index + 2):
        if all(blank(cell) for cell in row):
            continue  # empty spacer / formatting tail

        is_new_product = product_idx < len(row) and not blank(row[product_idx])

        if is_new_product:
            current = new_builder(row_number)
            for i, name in columns.items():
                key = norm_key(name)
                value = norm(row[i]) if i < len(row) else ""
                if not value:
                    continue
                if key in HEADER_TO_FIELD:
                    current["fields"][HEADER_TO_FIELD[key]] = value
                elif key == RECIPE_HEADER:
                    current["lines"].append(value)
            continue

        if current is None:
            # Stray line before any product: keep it instead of dropping it.
            current = new_builder(row_number)

        current["rows"].append(row_number)

        # Continuation row: merge every non-empty cell into the open record.
        for i, name in columns.items():
            if i >= len(row) or blank(row[i]):
                continue
            key = norm_key(name)
            value = norm(row[i])
            if key == RECIPE_HEADER or i == recipe_idx:
                current["lines"].append(value)
            elif key in HEADER_TO_FIELD:
                field_name = HEADER_TO_FIELD[key]
                existing = current["fields"].get(field_name)
                current["fields"][field_name] = f"{existing}\n{value}" if existing else value
            else:
                existing = current["merged"].get(name)
                current["merged"][name] = f"{existing}\n{value}" if existing else value

    products = tuple(_finish(builder, sheet_title) for builder in builders)
    return ManufacturerSheet(title=sheet_title, notes=notes, products=products)


def _sheets_from_workbook(workbook) -> dict[str, ManufacturerSheet]:
    try:
        data = {}
        for sheet in workbook.worksheets[1:]:  # skip the instructions sheet
            rows = list(sheet.iter_rows(values_only=True))
            data[sheet.title] = parse_sheet(rows, sheet.title)
        return data
    finally:
        workbook.close()


def download_sheets() -> dict[str, ManufacturerSheet]:
    """Fetch and parse the published sheet; raise if it carried no products.

    An empty result is treated as a failure on purpose: Google sometimes answers
    200 with a quota/login page, and an empty parse must never overwrite a good
    snapshot.
    """
    data = _sheets_from_workbook(fetch_workbook())
    if not any(len(sheet) for sheet in data.values()):
        raise ValueError("the downloaded workbook contained no products")
    return data


# ── snapshot: the committed fallback copy of the sheet ──────────────────────
def sheets_to_snapshot(data: dict[str, ManufacturerSheet], fetched_at: str) -> dict:
    """Plain-JSON form of the parsed sheets, so the fallback needs no xlsx."""
    return {
        "version": SNAPSHOT_VERSION,
        "source": URL,
        "fetched_at": fetched_at,
        "sheets": [
            {
                "title": sheet.title,
                "notes": list(sheet.notes),
                "products": [
                    {
                        "strain_name": product.strain_name,
                        "availability": product.availability,
                        "package_size": product.package_size,
                        "prescription_name": product.prescription_name,
                        "prescription_lines": list(product.prescription_lines),
                        "characteristics": product.characteristics,
                        "manufacturer_sheet": product.manufacturer_sheet,
                        "source_rows": product.source_rows,
                        "extra": [list(pair) for pair in product.extra],
                    }
                    for product in sheet.products
                ],
            }
            for sheet in data.values()
        ],
    }


def sheets_from_snapshot(blob: dict) -> dict[str, ManufacturerSheet]:
    """Rebuild the ``ManufacturerSheet`` mapping from a snapshot payload."""
    if blob.get("version") != SNAPSHOT_VERSION:
        raise ValueError(f"unsupported snapshot version {blob.get('version')!r}")
    data = {}
    for sheet in blob["sheets"]:
        data[sheet["title"]] = ManufacturerSheet(
            title=sheet["title"],
            notes=tuple(sheet.get("notes", ())),
            products=tuple(
                CannabisProduct(
                    strain_name=product["strain_name"],
                    availability=product["availability"],
                    package_size=product["package_size"],
                    prescription_name=product["prescription_name"],
                    prescription_lines=tuple(product["prescription_lines"]),
                    characteristics=product["characteristics"],
                    manufacturer_sheet=product.get("manufacturer_sheet", sheet["title"]),
                    source_rows=product.get("source_rows", ""),
                    extra=tuple(tuple(pair) for pair in product.get("extra", ())),
                )
                for product in sheet["products"]
            ),
        )
    return data


def read_snapshot() -> dict[str, ManufacturerSheet] | None:
    """The committed fallback, or ``None`` when there is no usable snapshot."""
    try:
        blob = json.loads(SNAPSHOT_PATH.read_text(encoding="utf-8"))
        return sheets_from_snapshot(blob)
    except FileNotFoundError:
        return None
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"warning: ignoring {SNAPSHOT_PATH.name} ({error})", file=sys.stderr)
        return None


def write_snapshot(data: dict[str, ManufacturerSheet]) -> bool:
    """Persist a freshly downloaded sheet; True only when the data changed.

    A run that downloads unchanged data leaves the file alone (and its
    ``fetched_at``), so a normal start does not dirty the working tree.
    """
    fetched_at = datetime.datetime.now(datetime.UTC).astimezone().isoformat(timespec="seconds")
    blob = sheets_to_snapshot(data, fetched_at)
    try:
        current = json.loads(SNAPSHOT_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        current = None
    if isinstance(current, dict) and current.get("sheets") == blob["sheets"]:
        return False

    text = json.dumps(blob, ensure_ascii=False, indent=1) + "\n"
    tmp = SNAPSHOT_PATH.with_name(SNAPSHOT_PATH.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, SNAPSHOT_PATH)  # atomic: a crash never leaves half a file
    return True


def load_all(workbook=None, *, refresh_snapshot: bool = True) -> dict[str, ManufacturerSheet]:
    """Sheets for this run, with the bundled snapshot as the offline fallback."""
    if workbook is not None:
        return _sheets_from_workbook(workbook)  # caller-supplied: no fetch, no write

    try:
        data = download_sheets()
    except Exception as error:  # any failure means "no sheet today"
        fallback = read_snapshot()
        if fallback is None:
            raise
        print(
            f"warning: could not read the sheet ({error}); "
            f"using {SNAPSHOT_PATH.name} instead",
            file=sys.stderr,
        )
        return fallback

    if refresh_snapshot:
        try:
            if write_snapshot(data):
                print(f"snapshot: refreshed {SNAPSHOT_PATH.name}")
        except OSError as error:
            print(f"warning: could not refresh {SNAPSHOT_PATH.name} ({error})", file=sys.stderr)
    return data


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """Close the automation browser when the panel shuts down."""
    yield
    await _app.state.issuer.aclose()


APP = FastAPI(lifespan=lifespan)
APP.state.issuer = BasketIssuer()
PAGE = Path(__file__).with_name("panel_receptowy_cannabis_flos_v2.html")


@APP.get("/")
def index() -> FileResponse:
    """Serve the doctor's panel."""
    return FileResponse(PAGE)


@APP.post("/api/recepta", status_code=202)
async def recepta(request: Request) -> dict:
    """Start issuing the basket the panel just submitted ("Wystaw").

    Returns immediately; the panel polls :func:`recepta_status` while the bot
    drives gabinet.gov.pl in a real Firefox window.
    """
    payload = await request.json()
    print("\n=== /api/recepta ===")
    print(json.dumps(payload, ensure_ascii=False, indent=2), flush=True)
    try:
        return APP.state.issuer.start(payload)
    except PayloadError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except RuntimeError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error


@APP.get("/api/recepta/status")
def recepta_status() -> dict:
    """Progress of the current basket: idle | running | login | signing | awaiting_sign | error.

    ``awaiting_sign`` is the normal end of a basket: the prescriptions are issued
    and handed to the e-ZLA popup, and the window stays open for the doctor.
    """
    return APP.state.issuer.status()


def _parser() -> argparse.ArgumentParser:
    """The panel's own flags: run.sh passes ``--port``/``--browser-idle`` only."""
    parser = argparse.ArgumentParser(
        prog="main.py", description="Doctor panel for cannabis prescriptions (gabinet.gov.pl)."
    )
    parser.add_argument(
        "--port", type=int, default=8000, help="HTTP port for the panel (default: 8000)"
    )
    # The browser is left open after signing so the next "Wystaw" reuses the
    # logged-in window; this is only the safety net for a doctor who never
    # comes back (it never fires while the e-ZLA popup waits for a password).
    parser.add_argument(
        "--browser-idle",
        type=float,
        default=3600.0,
        metavar="SECONDS",
        help="close the parked gabinet window after this much idle time, 0 = never "
        "(default: 3600)",
    )
    parser.add_argument(
        "--keep-open", action="store_true", help="leave the browser open after a failed run"
    )
    parser.add_argument(
        "--refresh-snapshot",
        action="store_true",
        help=f"only re-download the sheet into {SNAPSHOT_PATH.name} and exit",
    )
    return parser


def main() -> None:
    args = _parser().parse_args()
    configure_logging()

    if args.refresh_snapshot:
        try:
            data = download_sheets()
        except Exception as error:  # noqa: BLE001 - a bad download is any failure
            raise SystemExit(f"error: could not read the sheet ({error})") from None
        changed = write_snapshot(data)
        total = sum(len(sheet) for sheet in data.values())
        state = "refreshed" if changed else "already up to date"
        print(f"{SNAPSHOT_PATH.name} {state}: {len(data)} sheets, {total} products")
        return

    keep_open = args.keep_open
    port = args.port
    idle_timeout = args.browser_idle
    data = load_all()
    # TODO(sheet -> panel): informational only until the panel reads this instead
    # of its inlined CATALOG (see the module docstring).
    APP.state.sheets = data
    APP.state.issuer = BasketIssuer(keep_open=keep_open, idle_timeout_s=idle_timeout)
    print(
        f"issuer: keep_open={keep_open} browser_idle={idle_timeout:.0f}s (0 = never) "
        f"port={port}"
    )

    total = 0
    for sheet in data.values():
        total += len(sheet)
        multi = sum(1 for p in sheet if len(p.prescription_lines) > 1)
        gaps = sum(1 for p in sheet if not p.strain_name or not p.prescription_lines)
        print(
            f"{sheet.title:<18} products={len(sheet):>3}  "
            f"multi-line recipes={multi:>3}  gaps={gaps}  available={len(sheet.available()):>3}"
        )

    print(f"\ntotal products: {total}")

    sample = data["Aurora"].products[0]
    print("\nsample record (Aurora[0]):")
    print(f"  {sample!r}")
    print(f"\n  prescription:\n{sample.prescription}")

    print(f"\nserving {PAGE.name} on http://127.0.0.1:{port}", flush=True)
    uvicorn.run(APP, host="127.0.0.1", port=port)


if __name__ == "__main__":
    main()
