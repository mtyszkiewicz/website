"""First automated steps in gabinet.gov.pl: patient -> new Rpw prescription form.

The flow, exactly as performed by hand once:

1. open https://gabinet.gov.pl/wizyta/nowy
2. type the patient's PESEL into ``#pesel``
3. press "Zapisz dane pacjenta" -> redirected to /strona-glowna (gabinet
   refuses the save while the patient record has no address details; step 3 then
   waits up to 10 min for the doctor to complete them -- see ``_save_patient``)
4. click the "Rp -> Stwórz nową" card -> /rp/nowy
5. pick the "Recepturowy" radio on the prescription form
6. open the first ``span.cez-dropdown-label`` ("Kategoria dostępności") and choose "Rpw"
7. click the third ``span.cez-checkbox`` ("Wpisz ręcznie")
8. wait for ``#leki.0...skladnikRecznie`` and type the ingredient (``nazwa_skladnika``)
9. open "Skrót dotyczący ilości" (a ``cez-multiselect``) and pick ``A``
10. type the amount of the ingredient into ``Ilość``
11. pick ``g`` in the "Jednostka" dropdown
12. tick "Substancje odurzające i psychotropowe"
13. type the total active substance (``quantity * 1000``) and pick ``mg`` next to it
14. pick ``Spec.`` in "Postać leku. M.f."
15. type the written dosing sentence ("0.25g dwa razy dziennie w waporyzacji")
16. "Określ, czy świadczenie jest realizowane ... POZ lub NISOZ" -> Inna
17. "Określ tryb badania pacjenta" -> Badanie osobiste
18. click "Wystaw receptę"
19. accept the "ten składnik nie istnieje" popup with "Tak"
20. once the whole basket sits on /rp/lista: "Podpisz i wyślij wszystkie" ->
    "Podpisz certyfikatem e-ZLA"
21. stop on the "Podpis e-ZLA" popup (certificate + password), play a short
    fanfare and raise the window -- only the doctor can finish the signature

Step 21 is not automation's to finish: the e-ZLA password belongs to the
certificate, so the run parks there with the browser open and the doctor
signs, then starts the next patient with the panel's "Wystaw" button (the
same Firefox window is reused, so there is no mObywatel login again).

Quirk of the site: while a visit is open, /wizyta/nowy redirects to
/wizyta/edycja with the PESEL field disabled.  The flow therefore clicks the
misspelled ``.btn-zakoncz-wizyte`` button, returns to /wizyta/nowy and only then
enters the patient.

Everything from step 5 on lives inside open shadow roots (``app-root`` ->
``microservice-wrapper.shadowRoot``).  Playwright's CSS engine pierces open
shadow roots, so the selectors stay ordinary-looking; ``locator`` chains are
used instead of ``evaluate`` so every action gets auto-waiting.  Clicks target
the ``<label for=...>`` of the CEZ widget (the decorative circle/span does not
always toggle it) and every click is verified against the widget's own state.

Every step is snapshotted (screenshot + light/shadow-DOM HTML + widget probe)
into ``$XDG_STATE_HOME/aspot-bot/runs/<stamp>-<label>/`` -- see
:mod:`diagnostics`.

Usage::

    uv run python automation.py --pesel <PESEL>                  # sample line, steps 1-19
    uv run python automation.py --pesel <PESEL> --basket items.json
    uv run python automation.py --pesel <PESEL> --resume          # steps 5-19 on an open visit
    uv run python automation.py --pesel <PESEL> --prepare         # stop before "Wystaw receptę"
    uv run python automation.py --pesel <PESEL> --basket items.json --sign-all
    uv run python automation.py --pesel <PESEL> --trace           # snapshot every step
    uv run python automation.py --help

A patient's PESEL is never stored in this repository -- it is only ever passed
on the command line (or in a scratch basket file, which must never be committed).

``--basket`` takes the panel's own payload, ``{"pesel": ..., "items": [...]}``,
or a bare items array, so a dev run validates exactly what the panel would send.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import math
import re
import time
from collections.abc import Awaitable, Callable, Sequence
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from playwright.async_api import Error as PlaywrightError
from playwright.async_api import Locator, Page
from playwright.async_api import TimeoutError as PlaywrightTimeout

from browser import START_URL, open_session
from diagnostics import Recorder, configure_logging

logger = logging.getLogger(__name__)

HOME_PATTERN = "**/strona-glowna*"
RP_NEW_URL = "https://gabinet.gov.pl/rp/nowy"
RP_NEW_PATTERN = "**/rp/nowy*"

RESET_SELECTOR = ".btn-zakoncz-wizyte"
"""Ends an already-open visit; /wizyta/nowy redirects to /wizyta/edycja until then.

The class name is misspelled on gabinet's side ("wizyte", not "wizyta") and the
button is rendered twice (desktop + mobile), so it is always clicked via
``visible=true``."""

PESEL_SELECTOR = "#pesel"
PESEL_RADIO = "#numer-pesel-0"
SAVE_PATIENT_NAME = "Zapisz dane pacjenta"
RP_CARD_SELECTOR = "#strona-glowna-strona-glowna-card-rp-stworz-nowa"

# Shadow-DOM widgets (open roots, pierced by Playwright's CSS engine).
DROPDOWN_LABEL = "microservice-wrapper span.cez-dropdown-label"

RADIO_LABEL = "Recepturowy"
"""Prescription variant radio; matched by its visible label, not by index."""

PRESCRIPTION_KIND = "Rpw"
"""Variant picked from the first dropdown on the /rp/nowy form."""

CHECKBOX_INDEX = 2
"""Which ``span.cez-checkbox`` the hand-run clicked (0-based)."""

CHECKBOX_LABEL = "Wpisz ręcznie"
"""Checkbox picked after Rpw; its text is matched first, ``CHECKBOX_INDEX`` is the fallback."""

# Ingredient row (cez fields use dotted ids; they are stable per form array index).
INGREDIENT_NAME_ID = "leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.skladnikRecznie"
QUANTITY_ID = "cin-leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.ilosc"
SHORTCUT_ID = "leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.skrotDotyczacyIlosci"
UNIT_ID = "leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.jednostkaSkladnik"
NARCOTIC_LABEL = "Substancje odurzające i psychotropowe"
"""Checkbox marking the ingredient as a controlled substance."""

# Fields that only render once the narcotic checkbox is ticked.
TOTAL_DOSE_ID = "cin-leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.lacznaDawkaSubCzynnej"
TOTAL_DOSE_UNIT_ID = "leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.jednostkaSubCzynnej"
TOTAL_DOSE_WORDS_ID = "leki.0.lekRecepturowy.skladnikiLekuRecepturowego.0.lacznaDawkaSubCzynnejSlownie"
MF_ID = "leki.0.lekRecepturowy.mf"
DOSING_TEXT_ID = "leki.0.lekRecepturowy.dawkowaniePodstawowe.opisSlownyDawkowania"

TOTAL_DOSE_UNIT = "mg"
"""Unit for the total dose: quantity [g] * 1000."""

MF_VALUE = "Spec."
"""''Postać leku. M.f.'' -- the compounded-preparation form."""

POZ_RADIO = "Inna"
"""''Określ, czy świadczenie jest realizowane ... POZ lub NISOZ'' -> Inna."""

EXAM_MODE_RADIO = "Badanie osobiste"
"""''Określ tryb badania pacjenta'' -> Badanie osobiste (shown after picking Inna)."""

ISSUE_BUTTON = "Wystaw receptę"
"""Final submit button."""

ISSUE_WARNING_ACCEPT = "Tak"
"""Button in the "ten składnik nie istnieje" popup."""

SIGN_ALL_BUTTON = "Podpisz i wyślij wszystkie"
"""On /rp/lista: hand every pending prescription of the basket to signing."""

SIGN_EZLA_BUTTON = "Podpisz certyfikatem e-ZLA"
"""Signing method in the "Podpis recept" popup -- the doctor's certificate."""

SIGN_EZLA_HEADER = "Podpis e-ZLA"
"""Header of the popup that asks for the certificate and its password."""

MODAL_DIALOG = "[role=dialog][aria-modal=true]"
"""gabinet renders its popups as cdk-overlay panes; last visible = on top."""

FREQUENCY_WORDS = {2: "dwa", 3: "trzy", 4: "cztery"}
"""Polish numerals used in the written dosing sentence."""


def frequency_phrase(frequency: int) -> str:
    """'raz dziennie' for 1, 'dwa razy dziennie' for 2, ..."""
    if frequency == 1:
        return "raz dziennie"
    word = FREQUENCY_WORDS.get(frequency)
    if word is None:
        raise ValueError(f"unsupported frequency {frequency} (expected 1-4)")
    return f"{word} razy dziennie"


def dosing_description(dose: float, frequency: int, *, vapor: bool = True) -> str:
    """The "Opis słowny dawkowania" sentence, e.g. "0.25g dwa razy dziennie w waporyzacji"."""
    tail = " w waporyzacji" if vapor else ""
    return f"{dose:g}g {frequency_phrase(frequency)}{tail}"

STEP_TIMEOUT_MS = 45_000
"""Every wait in this module: page transitions and dynamic DOM alike."""

HOME_MARKER = "/strona-glowna"
"""The page "Zapisz dane pacjenta" redirects to (``HOME_PATTERN``)."""

PATIENT_GRACE_S = 15.0
"""A healthy save reaches /strona-glowna in ~1 s; past this the wait is announced."""

PATIENT_WAIT_S = 600.0
"""How long the doctor gets to complete a patient's missing address data.

gabinet refuses to save a patient whose record has no address ("Dane adresowe"):
the button stays disabled or the click only paints validation errors, and nobody
but the doctor can type them.  He never runs a command, so step 3 waits for its
redirect for ten minutes instead of failing after ``STEP_TIMEOUT_MS``."""

SAVE_CLICK_TIMEOUT_MS = 10_000
"""The save button is disabled while the address block is still incomplete."""


class StepFailed(RuntimeError):
    """A step did not reach its expected state; the message says what was seen."""


class OutcomeUnknown(StepFailed):
    """A submit was clicked but gabinet never confirmed the result: inspect it manually."""


@dataclass(frozen=True, slots=True)
class PrescriptionRequest:
    """The ingredient row of the Rpw form, filled from the panel's payload."""

    ingredient_name: str = (
        "Cannabis flos, S-LAB (THC 18% +/- 10%, CBD ≤ 1%), 15 g "
        "(piętnaście gramów kwiatu konopi)"
    )
    """``nazwa_skladnika`` -- typed into the manual ingredient field (default = the
    sample S-LAB 15 g cannabis flower line)."""

    quantity: float = 15.0
    """``quantity`` -- grams of the ingredient (the Ilość field)."""

    unit: str = "g"
    """``Jednostka`` dropdown value."""

    shortcut: str = "A"
    """``Skrót dotyczący ilości`` multiselect value."""

    narcotic: bool = True
    """Whether the controlled-substances checkbox is ticked."""

    dose: float = 0.25
    """``dose`` -- grams per single dose, used in the written dosing sentence."""

    frequency: int = 2
    """``frequency`` -- doses per day (1 -> "raz", 2 -> "dwa", ...)."""

    vapor: bool = True
    """``vapor`` -- append "w waporyzacji" to the written dosing sentence."""


@dataclass(slots=True)
class PrescriptionForm:
    """The /rp/nowy form once steps 5-12 have been configured."""

    page: Page
    """The page showing the configured prescription form."""

    radio: str
    """Label of the selected radio option (``Recepturowy``)."""

    kind: str
    """Value now displayed by the first dropdown (``Rpw``)."""

    checkbox_index: int
    """Which ``span.cez-checkbox`` was clicked."""

    checked: bool
    """Whether the "Wpisz ręcznie" checkbox reports itself as checked."""

    ingredient: str
    """Ingredient name typed into the manual field."""

    shortcut: str
    """Text now shown by the "Skrót dotyczący ilości" multiselect."""

    quantity: str
    """Value typed into the Ilość field."""

    unit: str
    """Text now shown by the Jednostka dropdown."""

    narcotic: bool
    """Whether "Substancje odurzające i psychotropowe" is ticked."""

    total_dose: str
    """Value + unit of "Łączna dawka substancji czynnej" (e.g. ``15000 mg``)."""

    mf: str
    """Value now shown by "Postać leku. M.f." (``Spec.``)."""

    dosing_text: str
    """The written dosing sentence typed into "Opis słowny dawkowania"."""

    visit_type: str
    """Selected POZ/NISOZ option (``Inna``)."""

    exam_mode: str
    """Selected examination mode (``Badanie osobiste``)."""

    issued: bool = False
    """Whether "Wystaw receptę" was clicked and the warning accepted."""

    issued_url: str | None = None
    """Where gabinet landed after issuing."""



class PayloadError(ValueError):
    """The panel's basket payload is not usable (returns HTTP 400)."""


ITEM_KEYS = {
    "manufacturer",
    "pack",
    "ingredient",
    "nazwa_skladnika",
    "quantity",
    "dose",
    "frequency",
    "vapor",
}
"""Keys the panel sends per basket line (``nazwa_skladnika`` becomes the ingredient)."""


def requests_from_payload(payload: Any) -> tuple[str, list[PrescriptionRequest]]:
    """Validate the panel payload and map it onto :class:`PrescriptionRequest`s."""
    if not isinstance(payload, dict):
        raise PayloadError("payload must be a JSON object")
    try:
        pesel = validate_pesel(str(payload.get("pesel", "")))
    except ValueError as error:
        raise PayloadError(str(error)) from None

    raw_items = payload.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        raise PayloadError("koszyk jest pusty")

    defaults = PrescriptionRequest()
    requests: list[PrescriptionRequest] = []
    for index, raw in enumerate(raw_items, start=1):
        if not isinstance(raw, dict):
            raise PayloadError(f"pozycja {index} nie jest obiektem")
        unknown = set(raw) - ITEM_KEYS
        if unknown:
            raise PayloadError(f"pozycja {index} ma nieznane pola: {sorted(unknown)}")
        try:
            quantity = raw["quantity"]
            dose = raw.get("dose", defaults.dose)
            frequency = raw.get("frequency", defaults.frequency)
            vapor = raw.get("vapor", defaults.vapor)
            if (isinstance(quantity, bool) or isinstance(dose, bool)
                or isinstance(frequency, bool) or not isinstance(vapor, bool)):
                raise TypeError("wrong field type")
            quantity = float(quantity)
            dose = float(dose)
            if not isinstance(frequency, int):
                raise TypeError("frequency must be an integer")
            if not math.isfinite(quantity) or quantity <= 0 or not math.isfinite(dose) or dose <= 0:
                raise ValueError("quantity and dose must be positive finite numbers")
            request = PrescriptionRequest(
                ingredient_name=str(raw.get("nazwa_skladnika") or "").strip(),
                quantity=quantity,
                dose=dose,
                frequency=frequency,
                vapor=vapor,
            )
        except (KeyError, TypeError, ValueError) as error:
            raise PayloadError(f"pozycja {index} jest nieprawidłowa: {error}") from None
        if not request.ingredient_name:
            raise PayloadError(f"pozycja {index} nie ma nazwy składnika")
        try:
            frequency_phrase(request.frequency)
        except ValueError as error:
            raise PayloadError(f"pozycja {index}: {error}") from None
        if request.quantity / (request.dose * request.frequency) > 90:
            raise PayloadError(f"pozycja {index} przekracza 90 dni terapii")
        requests.append(request)
    days = sum(item.quantity / (item.dose * item.frequency) for item in requests)
    if days > 90:
        raise PayloadError("łączny czas terapii w koszyku przekracza 90 dni")
    return pesel, requests


def validate_pesel(pesel: str) -> str:
    """Return the PESEL unchanged, or raise ValueError if it cannot be valid.

    Cheap client-side guard: 11 digits plus the official checksum.  A typo here
    would create a visit for the wrong (or a non-existent) patient.
    """
    digits = pesel.strip()
    if not re.fullmatch(r"[0-9]{11}", digits):
        raise ValueError("PESEL must be 11 ASCII digits")
    weights = (1, 3, 7, 9, 1, 3, 7, 9, 1, 3)
    numbers = [ord(digit) - ord("0") for digit in digits]  # ASCII digits -> ints
    checksum = sum(number * weight for number, weight in zip(numbers[:10], weights, strict=True)) % 10
    if (10 - checksum) % 10 != numbers[10]:
        raise ValueError("PESEL has an invalid checksum")
    return digits


_STARTED = time.monotonic()


async def _snap(
    recorder: Recorder | None, page: Page, stage: str, *, force: bool = False
) -> None:
    """Snapshot a stage when a recorder is attached (no-op otherwise)."""
    if recorder is not None:
        await recorder.snap(page, stage, force=force)


def _log(step: str, detail: str = "", recorder: Recorder | None = None) -> None:
    elapsed = time.monotonic() - _STARTED
    line = f"[{step} +{elapsed:.0f}s]{' ' + detail if detail else ''}"
    print(line, flush=True)
    if recorder is not None:
        recorder.note(line)


async def _poll_state(
    fetch: Callable[[], Awaitable[Any]],
    ready: Callable[[Any], bool],
    *,
    timeout_ms: int = 5_000,
) -> Any:
    """Re-read widget state every 50 ms until ``ready`` says it settled."""
    state = await fetch()
    deadline = time.monotonic() + timeout_ms / 1000
    while not ready(state) and time.monotonic() < deadline:
        await asyncio.sleep(0.05)
        state = await fetch()
    return state


async def _wait_for_url(page: Page, pattern: str, step: str) -> None:
    """Wait for a redirect; on timeout report what the page actually shows."""
    try:
        await page.wait_for_url(pattern, timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        body = (await page.inner_text("body"))[:600].strip()
        raise StepFailed(f"{step}: expected URL {pattern}, still at {page.url}\n{body}") from None


def _first_visible(locator: Locator) -> Locator:
    """Locator restricted to rendered matches (shadow-piercing still applies)."""
    return locator.locator("visible=true").first


async def _click_first_visible(locator: Locator, step: str) -> None:
    target = _first_visible(locator)
    try:
        await target.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(f"{step}: no visible {locator!s}") from None
    await target.click()


async def _visit_state(page: Page, timeout_ms: int = 15_000) -> str:
    """'edit' when an old visit blocks /wizyta/nowy, 'new' when the form is usable.

    gabinet answers /wizyta/nowy with an SPA redirect to /wizyta/edycja while a
    visit is open; the redirect is client-side, so poll instead of trusting the
    first paint.
    """
    deadline = time.monotonic() + timeout_ms / 1000
    while True:
        if "/wizyta/edycja" in page.url:
            return "edit"
        try:
            pesel_input = page.locator(PESEL_SELECTOR)
            if await pesel_input.count() and await pesel_input.is_enabled():
                return "new"
        except PlaywrightError as error:
            logger.debug("visit state probe skipped: %s", error)
        if time.monotonic() >= deadline:
            return "unknown"
        await asyncio.sleep(0.1)


DIALOG_SELECTOR = (
    "[role=dialog], [role=alertdialog], .modal.show, .cdk-dialog-container, cez-modal"
)
"""Any of gabinet's confirmation popups (visit end, ingredient warning, ...)."""

DIALOG_ACCEPT = re.compile(
    r"tak|zakończ|zakoncz|potwierdź|potwierdz|ignoruj|utwórz|utworz", re.IGNORECASE
)
"""Buttons that mean "yes" in those popups ("Tak", "Tak, zakończ", ...)."""


async def _accept_dialog_if_any(page: Page, rec: Recorder | None = None) -> bool:
    """Click the affirmative button of a visible popup, if there is one."""
    dialog = page.locator(DIALOG_SELECTOR)
    try:
        if not await dialog.count():
            return False
        box = dialog.locator("visible=true").first
        if not await box.is_visible():
            return False
        accept = box.get_by_role("button").filter(has_text=DIALOG_ACCEPT).locator("visible=true").first
        if await accept.count():
            text = " ".join((await accept.inner_text()).split())[:40]
            _log("popup", f"clicking {text!r}", rec)
            await accept.click()
            return True
        primary = box.locator(".btn-primary").locator("visible=true").first
        if await primary.count():
            await primary.click()
            return True
    except PlaywrightError as error:
        logger.debug("dialog probe skipped: %s", error)
    return False


async def _wait_until_visit_closed(
    page: Page, rec: Recorder | None = None, timeout_ms: int = 60_000
) -> None:
    """Wait for the SPA to leave /wizyta/edycja, answering popups on the way.

    "Zakończenie obsługi pacjenta" appears a moment *after* the button click, so
    a single check is not enough -- and sitting in a 90 s URL wait while that
    dialog blocks the page is exactly what looked like a hang.
    """
    deadline = time.monotonic() + timeout_ms / 1000
    last_report = time.monotonic()
    while time.monotonic() < deadline:
        if "/wizyta/edycja" not in page.url:
            return
        if await _accept_dialog_if_any(page, rec):
            continue
        await asyncio.sleep(0.15)
        if time.monotonic() - last_report > 5:
            last_report = time.monotonic()
            _log("1/19 reset", "gabinet is still closing the visit…", rec)
    raise PlaywrightTimeout(f"visit did not close, still at {page.url}")


async def _end_visit(page: Page, rec: Recorder | None) -> None:
    """Quirk of gabinet: an open visit blocks the next patient, so end it first."""
    _log("1/19 reset", f"/wizyta/nowy redirected to {page.url} -- an older visit is open", rec)
    _log("1/19 reset", f"clicking {RESET_SELECTOR}", rec)
    await _click_first_visible(page.locator(RESET_SELECTOR), "1/19 reset")
    await _snap(rec, page, "02-visit-end-clicked")
    await _accept_dialog_if_any(page)

    # gabinet asks "Zakończenie obsługi pacjenta" a moment later and then needs a
    # few seconds to close the visit server-side.  Answer popups while waiting.
    _log("1/19 reset", "waiting for gabinet to close the visit…", rec)
    try:
        await _wait_until_visit_closed(page, rec)
    except PlaywrightTimeout:
        raise StepFailed(
            f"1/19 reset: still at {page.url} after clicking {RESET_SELECTOR}"
        ) from None
    _log("1/19 reset", f"visit ended, now at {page.url}", rec)


NEXT_PRESCRIPTION = "Nowa recepta"
"""Button on /rp/lista that opens a fresh /rp/nowy for the next basket line."""


async def _open_patient_form(page: Page, rec: Recorder | None) -> None:
    """Open the patient form after the visit was closed.

    The "Dane pacjenta" header entry is the same route, but it sits in a collapsed
    menu (invisible, and a click on it hangs waiting for actionability), so the
    direct route is both faster and deterministic.
    """
    _log("1/19", f"opening {START_URL} for the patient data", rec)
    await page.goto(START_URL, wait_until="commit", timeout=STEP_TIMEOUT_MS)
    with suppress(PlaywrightTimeout):
        await page.wait_for_url("**/wizyta/**", timeout=STEP_TIMEOUT_MS)
    await _snap(rec, page, "02-visit-new")


async def _save_patient(
    page: Page,
    rec: Recorder | None,
    on_wait: Callable[[bool], None] | None = None,
) -> None:
    """Step 3: save the patient and follow the redirect to /strona-glowna.

    gabinet refuses the save when the patient record has no address details
    ("Aktualny adres pobytu na terenie Polski": województwo, kod pocztowy,
    miejscowość, ulica and numer budynku are all required): the button stays
    disabled, or the click only paints validation errors on that block.  Only the
    doctor can type those, so the run *waits* for the redirect (up to
    ``PATIENT_WAIT_S``) rather than failing after ``STEP_TIMEOUT_MS``;
    ``on_wait(True)`` asks the panel to tell him what is missing, ``on_wait(False)``
    says the save went through.
    """
    _log("3/19", f'clicking "{SAVE_PATIENT_NAME}"', rec)
    button = page.get_by_role("button", name=SAVE_PATIENT_NAME, exact=True).first
    try:
        await button.click(timeout=SAVE_CLICK_TIMEOUT_MS)
    except PlaywrightTimeout:
        _log("3/19", f'"{SAVE_PATIENT_NAME}" is not clickable yet -- waiting for the doctor', rec)

    started = time.monotonic()
    deadline = started + PATIENT_WAIT_S
    announced = False
    last_report = started
    while HOME_MARKER not in page.url:
        now = time.monotonic()
        if now >= deadline:
            body = (await page.inner_text("body"))[:600].strip()
            raise StepFailed(
                f"3/19 saving the patient: {SAVE_PATIENT_NAME} never reached "
                f"{HOME_PATTERN} within {PATIENT_WAIT_S / 60:.0f} min "
                f"(missing address data?), still at {page.url}\n{body}"
            )
        if not announced and now - started > PATIENT_GRACE_S:
            announced = True
            if on_wait is not None:
                on_wait(True)
            _log(
                "3/19",
                "gabinet did not save the patient -- probably missing address data. "
                'Complete it in the open Firefox window and press "'
                f'{SAVE_PATIENT_NAME}"; waiting up to {PATIENT_WAIT_S / 60:.0f} min.',
                rec,
            )
        elif announced and now - last_report > 30:
            last_report = now
            _log("3/19", f"still waiting for {HOME_MARKER} ({deadline - now:.0f}s left)", rec)
        await asyncio.sleep(0.2)

    if announced and on_wait is not None:
        on_wait(False)
    _log("3/19", f"patient saved, now at {page.url}", rec)


async def _fill_patient(
    page: Page,
    pesel: str,
    rec: Recorder | None,
    on_wait: Callable[[bool], None] | None = None,
) -> bool:
    """Steps 1-3: land on the visit form, fill the PESEL, save the patient.

    Step 3 may park here for up to ``PATIENT_WAIT_S`` when the patient record has
    no address details (see :func:`_save_patient`) -- the doctor completes them in
    this same window and the flow continues.

    Returns True when the open visit already belonged to this patient and the
    flow jumped straight to /rp/nowy (the caller then skips step 4).

    gabinet keeps a visit in the session, so a rerun lands on /wizyta/edycja with
    the PESEL field disabled.  Per the site's behaviour the open visit is ended
    (``.btn-zakoncz-wizyta``) and /wizyta/nowy is opened again before continuing;
    otherwise the flow would silently reuse the previous patient.
    """
    _log("1/19", f"opening {START_URL}", rec)
    if not page.url.startswith(START_URL):
        # "commit": return as soon as the response starts; the element waits below
        # are the real readiness signal (and this saves ~1-2 s per navigation).
        await page.goto(START_URL, wait_until="commit", timeout=STEP_TIMEOUT_MS)

    state = await _visit_state(page)
    if state == "edit":
        attached = (await page.locator(PESEL_SELECTOR).input_value()).strip()
        if attached == pesel:
            _log("1/19", "visit already belongs to this patient -- skipping reset", rec)
            await page.goto(RP_NEW_URL, wait_until="commit", timeout=STEP_TIMEOUT_MS)
            if "/rp/nowy" not in page.url:
                raise StepFailed(f"1/19: {RP_NEW_URL} redirected to {page.url}")
            await _wait_form_ready(page, rec)
            await _snap(rec, page, "04-rp-nowy")
            return True
        await _end_visit(page, rec)
        await _open_patient_form(page, rec)
        state = await _visit_state(page)
        if state != "new":
            raise StepFailed(f"1/19: /wizyta/nowy still is not a fresh form (url {page.url})")
    elif state != "new":
        raise StepFailed(f"1/19: /wizyta/nowy never became usable (url {page.url})")

    pesel_input = page.locator(PESEL_SELECTOR)
    if not await pesel_input.is_visible():
        # "Inny identyfikator" may be preselected: switch to the PESEL radio first.
        await page.locator(PESEL_RADIO).click(force=True)
        await pesel_input.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)

    _log("2/19", "typing patient identifier", rec)
    await pesel_input.fill(pesel)
    await _snap(rec, page, "02-pesel-typed")

    await _save_patient(page, rec, on_wait)
    await _snap(rec, page, "03-home")
    return False


async def _wait_form_ready(page: Page, rec: Recorder | None) -> None:
    """Wait until the shadow-DOM prescription form actually rendered.

    /rp/nowy is an empty shell for several seconds: the CEZ widgets only appear
    once the lazily-loaded microservice-wrapper micro-frontend boots, so every
    selector below would otherwise race the render.
    """
    _log("4/19", "waiting for the prescription form to render", rec)
    try:
        await page.locator("microservice-wrapper span.cez-radiobutton-circle").first.wait_for(
            state="visible", timeout=STEP_TIMEOUT_MS
        )
    except PlaywrightTimeout:
        raise StepFailed("the prescription form never rendered (no cez-radiobutton-circle)") from None


async def _open_next_prescription(page: Page, rec: Recorder | None) -> None:
    """After an issuance gabinet sits on /rp/lista: use "Nowa recepta"."""
    _log("4/19", f"clicking \"{NEXT_PRESCRIPTION}\" on the prescriptions list", rec)
    button = page.get_by_role("button", name=NEXT_PRESCRIPTION, exact=True).first
    if not await button.count():
        button = page.get_by_role("link", name=NEXT_PRESCRIPTION, exact=True).first
    try:
        await button.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(
            f'4/19: "{NEXT_PRESCRIPTION}" never appeared on {page.url}'
        ) from None
    await button.click()
    await _wait_for_url(page, RP_NEW_PATTERN, "4/19 opening /rp/nowy")
    await _wait_form_ready(page, rec)
    await _snap(rec, page, "04-rp-nowy")


async def _open_prescription_form(page: Page, rec: Recorder | None) -> None:
    """Step 4: from the home screen into the new-prescription form."""
    _log("4/19", "opening the 'Rp -> Stwórz nową' card", rec)
    await page.locator(RP_CARD_SELECTOR).click()
    await _wait_for_url(page, RP_NEW_PATTERN, "4/19 opening /rp/nowy")
    await _wait_form_ready(page, rec)
    await _snap(rec, page, "04-rp-nowy")


# --- shadow-DOM widget handling ------------------------------------------------

# JS helper installed once per page: deep element walk + visibility test.
_HELPERS_JS = """
() => {
  if (window.__aspot) return;
  window.__aspot = {
    all() {
      const seen = [];
      const walk = (root) => {
        for (const el of root.querySelectorAll('*')) {
          if (el.shadowRoot) walk(el.shadowRoot);
          seen.push(el);
        }
      };
      walk(document);
      return seen;
    },
    visible(el) {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== 'hidden';
    },
    clearMarks() {
      const attrs = [
        'data-aspot-label', 'data-aspot-circle', 'data-aspot-input',
        'data-aspot-checkbox', 'data-aspot-checkbox-label', 'data-aspot-dropdown-label',
      ];
      for (const el of this.all()) {
        for (const attr of attrs) if (el.hasAttribute(attr)) el.removeAttribute(attr);
      }
    },
  };
}
"""

# A CEZ radio option is
#   <cez-radio-button>
#     <div class="cez-radiobutton-wrap cez-radiobutton [cez-radiobutton-checked]">
#       <div class="cez-hidden-accessible"><input type=radio id=..., aria-checked=...></div>
#       <div class="cez-radiobutton-box"><span class="cez-radiobutton-circle"></span></div>
#     </div>
#     <label class="cez-radiobutton-label" for="<input id>">Recepturowy</label>
#   </cez-radio-button>
# so the label is what identifies the option, the preceding wrap holds the input,
# and the wrap's `cez-radiobutton-checked` class is the state marker.
_RADIO_TARGET_JS = """
(text) => {
  const h = window.__aspot;
  h.clearMarks();
  const label = h.all().find((el) => {
    const cls = typeof el.className === 'string' ? el.className : '';
    return cls.includes('cez-radiobutton-label')
      && el.textContent.trim() === text
      && h.visible(el);
  });
  if (!label) return null;
  label.setAttribute('data-aspot-label', '1');
  const wrap = label.previousElementSibling;
  const circle = wrap ? wrap.querySelector('.cez-radiobutton-circle') : null;
  const input = wrap ? wrap.querySelector('input[type=radio]') : null;
  if (circle) circle.setAttribute('data-aspot-circle', '1');
  if (input) input.setAttribute('data-aspot-input', '1');
  return {
    labelText: label.textContent.trim().slice(0, 80),
    for: label.getAttribute('for'),
    hasCircle: !!circle,
    hasInput: !!input,
  };
}
"""

_RADIO_STATE_JS = """
(text) => {
  const h = window.__aspot;
  const reports = h.all()
    .filter((el) => {
      const cls = typeof el.className === 'string' ? el.className : '';
      return cls.includes('cez-radiobutton-label') && el.textContent.trim() === text;
    })
    .map((label) => {
      const wrap = label.previousElementSibling;
      const input = wrap ? wrap.querySelector('input[type=radio]') : null;
      return {
        labelText: label.textContent.trim().slice(0, 80),
        inputChecked: input ? input.checked : null,
        inputAria: input ? input.getAttribute('aria-checked') : null,
        wrapCls: wrap ? String(wrap.className).trim().slice(0, 200) : null,
        labelCls: String(label.className).trim().slice(0, 120),
      };
    });
  const checked = reports.some((r) => r.inputChecked === true
    || r.inputAria === 'true'
    || /radiobutton-checked/.test(r.wrapCls || '')
    || /label--active/.test(r.labelCls || ''));
  return {checked, reports};
}
"""

# The dropdown panel is rendered by a lazily-loaded CEZ component whose item
# class names are in no stylesheet served with /wizyta/nowy, so instead of
# guessing classes we look for the rendered element whose exact text is the
# option label.  Walks every open shadow root; `closest` keeps the selected
# label itself out of the results (it may already read 'Rpw' after a rerun).
_DEEP_OPTION_JS = """
(text) => {
  const h = window.__aspot;
  const matches = h.all().filter((el) => {
    if (!h.visible(el)) return false;
    if (el.closest('.cez-dropdown-label')) return false;
    return el.textContent.trim() === text;
  });
  if (!matches.length) return null;
  const options = matches.filter((el) => el.getAttribute('role') === 'option');
  const items = matches.filter((el) => el.tagName === 'LI');
  const leaves = matches.filter((el) => !matches.some((other) => other !== el && el.contains(other)));
  return (options[0] || items[0] || leaves[0] || matches[0]);
}
"""


async def _select_radio(
    page: Page, text: str, rec: Recorder | None, *, step: str = "5/19"
) -> str:
    """Pick the radio option labelled ``text`` and prove it became selected.

    Clicks are tried in order of "what a human does": the label (it carries the
    ``for`` link), then the decorative circle, then the hidden input.  Every
    attempt is verified against the wrap class / input state, so a no-op click
    can never be reported as success.
    """
    await page.evaluate(_HELPERS_JS)
    _log(step, f"selecting radio {text!r}", rec)
    try:
        info: dict[str, Any] | None = await page.evaluate(_RADIO_TARGET_JS, text)
        if info is None:
            raise StepFailed(f"{step}: no visible radio label {text!r} on {page.url}")
        await _snap(rec, page, f"{step.replace('/', '-')}-radio-before")

        attempts = ("label", '[data-aspot-label="1"]'), ("circle", '[data-aspot-circle="1"]')
        state: dict[str, Any] = await page.evaluate(_RADIO_STATE_JS, text)
        used = "already selected"
        for how, selector in attempts:
            if state["checked"]:
                break
            target = page.locator(selector)
            if not await target.count():
                continue
            await target.click()
            state = await _poll_state(
                lambda: page.evaluate(_RADIO_STATE_JS, text), lambda value: value["checked"]
            )
            used = how
        if not state["checked"] and info["hasInput"]:
            await page.locator('[data-aspot-input="1"]').check(force=True)
            state = await _poll_state(
                lambda: page.evaluate(_RADIO_STATE_JS, text), lambda value: value["checked"]
            )
            used = "input"

        await _snap(rec, page, f"{step.replace('/', '-')}-radio")
        if not state["checked"]:
            raise StepFailed(
                f"{step}: radio {text!r} still not selected after label/circle/input clicks; "
                f"observed: {state['reports']}"
            )
        _log(step, f"radio {text!r} selected via {used} (for={info['for']})", rec)
    except PlaywrightError as error:
        raise StepFailed(f"{step}: radio {text!r} failed: {error}") from error
    return text


_DROPDOWN_TARGET_JS = """
() => {
  const h = window.__aspot;
  h.clearMarks();
  const label = h.all().find((el) => {
    const cls = typeof el.className === 'string' ? el.className : '';
    return el.tagName === 'SPAN' && cls.includes('cez-dropdown-label') && h.visible(el);
  });
  if (!label) return null;
  // the `inputid` lives on the <cez-dropdown> host, not on the inner div
  const container = label.closest('cez-dropdown') || label.closest('.cez-dropdown') || label.parentElement;
  label.setAttribute('data-aspot-dropdown-label', '1');
  return {
    labelText: label.textContent.trim().slice(0, 100),
    inputId: container ? container.getAttribute('inputid') : null,
  };
}
"""

# Checkbox structure:
#   <cez-checkbox class="cez-checkbox-container ...">
#     <div class="cez-checkbox-wrap"><div class="cez-hidden-accessible">
#       <input type="checkbox" id="..."></div><span class="cez-checkbox"></span></div>
#     <label for="...">Wpisz ręcznie</label>
#   </cez-checkbox>
# The label carries the `for` link, so it is the reliable click target; the span
# is kept as a fallback because that is what the hand-run used.
_CHECKBOX_TARGET_JS = r"""
({index, labelText}) => {
  const h = window.__aspot;
  h.clearMarks();
  const spans = h.all().filter((el) => {
    const cls = typeof el.className === 'string' ? el.className : '';
    return el.tagName === 'SPAN' && cls.split(/\s+/).includes('cez-checkbox');
  });
  const describe = (span, i) => {
    const container = span.closest('cez-checkbox');
    const input = container ? container.querySelector('input[type=checkbox]') : null;
    const label = container ? container.querySelector('label[for]') : null;
    return {
      index: i,
      text: container ? (container.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 120) : null,
      inputId: input ? input.id : label ? label.getAttribute('for') : null,
    };
  };
  const described = spans.map(describe);
  const wanted = String(labelText).toLowerCase();
  let chosen = described.find((d) => (d.text || '').toLowerCase().includes(wanted));
  if (!chosen) chosen = described.find((d) => d.index === index);
  if (!chosen) return {chosen: null, spans: described};
  const span = spans[chosen.index];
  const container = span.closest('cez-checkbox');
  const label = container ? container.querySelector('label[for]') : null;
  span.setAttribute('data-aspot-checkbox', '1');
  if (label) label.setAttribute('data-aspot-checkbox-label', '1');
  return {chosen, spans: described};
}
"""

_CHECKBOX_STATE_JS = r"""
(index) => {
  const h = window.__aspot;
  const spans = h.all().filter((el) => {
    const cls = typeof el.className === 'string' ? el.className : '';
    return el.tagName === 'SPAN' && cls.split(/\s+/).includes('cez-checkbox');
  });
  const span = spans[index];
  if (!span) return null;
  const container = span.closest('cez-checkbox');
  const input = container ? container.querySelector('input[type=checkbox]') : null;
  return {
    text: container ? (container.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 120) : null,
    inputId: input ? input.id : null,
    inputChecked: input ? input.checked : null,
    spanCls: String(span.className).trim(),
  };
}
"""


async def _pick_dropdown_option(page: Page, text: str, step: str, rec: Recorder | None) -> str:
    """Click the open dropdown's option labelled ``text``; return what worked."""
    selector = f'[role=option][aria-label="{text}"]'
    option = page.locator(selector).locator("visible=true").first
    try:
        await option.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        logger.debug("no aria-label option for %r; trying fallbacks", text)
    else:
        await option.click()
        _log(step, f"picked {text!r} via {selector}", rec)
        return selector

    # Fallbacks for releases whose options are not role=option/aria-label.
    handle = await page.evaluate_handle(_DEEP_OPTION_JS, text)
    element = handle.as_element()
    if element is not None:
        await element.scroll_into_view_if_needed()
        await element.click()
        _log(step, f"picked {text!r} via exact-text lookup", rec)
        return "exact-text"

    for candidate in (f"[role=option]:has-text('{text}')", f"li:has-text('{text}')"):
        fallback = page.locator(candidate).locator("visible=true").first
        try:
            await fallback.wait_for(state="visible", timeout=3_000)
        except PlaywrightTimeout:
            continue
        await fallback.click()
        _log(step, f"picked {text!r} via {candidate}", rec)
        return candidate
    raise StepFailed(f"{step}: dropdown option {text!r} never appeared")


async def _select_dropdown(
    page: Page,
    text: str,
    rec: Recorder | None,
    *,
    input_id: str | None = None,
    step: str = "6/19",
    snap_prefix: str = "06-dropdown",
) -> str:
    """Open a CEZ dropdown, choose ``text``, then verify the selection stuck.

    ``input_id`` picks a specific dropdown (the ingredient's ``Jednostka``); by
    default the first one on the form is used (``Kategoria dostępności``).
    """
    if input_id is None:
        _log(step, f"opening the first dropdown ({DROPDOWN_LABEL})", rec)
        try:
            await page.locator(DROPDOWN_LABEL).first.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
        except PlaywrightTimeout:
            raise StepFailed(f"{step}: no cez-dropdown-label appeared after switching to Recepturowy") from None
        info: dict[str, Any] | None = await page.evaluate(_DROPDOWN_TARGET_JS)
        if info is None:
            raise StepFailed(f"{step}: the dropdown label could not be located")
        input_id = info.get("inputId")
        target = page.locator('[data-aspot-dropdown-label="1"]')
    else:
        _log(step, f"opening dropdown {input_id}", rec)
        owner = page.locator(f'cez-dropdown[inputid="{input_id}"]').first
        try:
            await owner.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
        except PlaywrightTimeout:
            raise StepFailed(f"{step}: dropdown {input_id} never rendered") from None
        target = _first_visible(owner.locator(".cez-dropdown-label"))

    await target.click()
    with suppress(PlaywrightTimeout):
        await page.locator("[role=option]").locator("visible=true").first.wait_for(
            state="visible", timeout=5_000
        )
    await _snap(rec, page, f"{snap_prefix}-open")

    await _pick_dropdown_option(page, text, step, rec)
    await _snap(rec, page, f"{snap_prefix}-picked")

    if not input_id:
        raise StepFailed(f"{step}: the dropdown has no inputid attribute to verify against")
    # Verify through the stable `inputid` attribute: the form re-renders after the
    # selection, so marks set on the old nodes are gone (but the id survives).
    container = page.locator(f'cez-dropdown[inputid="{input_id}"]').first
    label_now = _first_visible(container.locator(".cez-dropdown-label"))

    async def label_text() -> str:
        with suppress(PlaywrightError):
            return (await label_now.inner_text()).strip()
        return ""

    shown = await _poll_state(label_text, lambda value: text in value)
    if text not in shown:
        raise StepFailed(f"{step}: dropdown {input_id} shows {shown!r}, expected {text!r}")
    _log(step, f"dropdown {input_id} now reads {shown!r}", rec)
    return shown


async def _select_checkbox(
    page: Page, index: int, label_text: str, rec: Recorder | None, *, step: str = "7/19"
) -> tuple[bool, int]:
    """Step 7/19: check the ``span.cez-checkbox`` for ``label_text`` (index fallback)."""
    _log(step, f"selecting checkbox {label_text!r} (index {index} fallback)", rec)
    info: dict[str, Any] = await page.evaluate(
        _CHECKBOX_TARGET_JS, {"index": index, "labelText": label_text}
    )
    chosen = info["chosen"]
    if chosen is None:
        raise StepFailed(f"{step}: no cez-checkbox for {label_text!r} or index {index}: {info['spans']}")
    logger.debug("checkboxes: %s", info["spans"])
    checkbox_index = int(chosen["index"])
    _log(step, f"target: {chosen} of {len(info['spans'])} checkboxes", rec)

    state: dict[str, Any] | None = await page.evaluate(_CHECKBOX_STATE_JS, checkbox_index)
    used = "already checked"
    for how, selector in (
        ("label", '[data-aspot-checkbox-label="1"]'),
        ("span", '[data-aspot-checkbox="1"]'),
    ):
        if state is not None and state["inputChecked"]:
            break
        target = page.locator(selector).first
        if not await target.count():
            continue
        await target.click()
        state = await _poll_state(
            lambda: page.evaluate(_CHECKBOX_STATE_JS, checkbox_index),
            lambda value: bool(value and value["inputChecked"]),
        )
        used = how

    if state is not None and state["inputChecked"] is not True and state.get("inputId"):
        hidden = page.locator(f'[id="{state["inputId"]}"]')
        if await hidden.count():
            await hidden.check(force=True)
            state = await _poll_state(
                lambda: page.evaluate(_CHECKBOX_STATE_JS, checkbox_index),
                lambda value: bool(value and value["inputChecked"]),
            )
            used = "input"

    await _snap(rec, page, f"{step.replace('/', '-')}-checkbox")
    if state is None or not state["inputChecked"]:
        raise StepFailed(f"{step}: checkbox {label_text!r} still unchecked: {state}")
    _log(step, f"checkbox {state['text']!r} checked via {used} (input {state['inputId']})", rec)
    return True, checkbox_index


async def _close_overlays(page: Page) -> None:
    """Dismiss open CDK overlays: their transparent backdrop swallows every click.

    The ``cez-multiselect`` (Skrót dotyczący ilości) leaves its panel open after a
    selection, unlike plain dropdowns, so the next field cannot be clicked until
    it is closed.
    """
    for _ in range(5):
        if not await page.locator(".cdk-overlay-backdrop").count():
            return
        await page.keyboard.press("Escape")
        await asyncio.sleep(0.1)
    raise StepFailed("a CDK overlay stayed open and blocks the form")


async def _fill_ingredient(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> None:
    """Step 8: type the manual ingredient name (``nazwa_skladnika``)."""
    _log("8/19", f"typing ingredient name {request.ingredient_name!r}", rec)
    field = page.locator(f'[id="{INGREDIENT_NAME_ID}"]')
    try:
        await field.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(
            "8/19: the manual ingredient field never appeared -- is 'Wpisz ręcznie' ticked?"
        ) from None
    await field.fill(request.ingredient_name)
    await field.press("Tab")
    typed = await field.input_value()
    if typed != request.ingredient_name:
        raise StepFailed(f"8/19: ingredient field holds {typed!r}")
    await _snap(rec, page, "09-ingredient-typed")


async def _select_shortcut(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> str:
    """Step 9: open "Skrót dotyczący ilości" (a cez-multiselect) and pick the letter."""
    _log("9/19", f"picking quantity shortcut {request.shortcut!r}", rec)
    owner = page.locator(f'cez-multiselect[inputid="{SHORTCUT_ID}"]').first
    try:
        await owner.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed("9/19: the 'Skrót dotyczący ilości' multiselect never rendered") from None
    trigger = owner.locator("[role=button]").first
    if not await trigger.count():
        trigger = owner.locator(".cez-multiselect__input").first
    await trigger.click()
    with suppress(PlaywrightTimeout):
        await page.locator("cez-option").first.wait_for(state="visible", timeout=5_000)
    await _snap(rec, page, "10-shortcut-open")

    pattern = re.compile(rf"^\s*{re.escape(request.shortcut)}\s*$")
    option = page.locator("cez-option").filter(has_text=pattern).first
    try:
        await option.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(f"9/19: option {request.shortcut!r} never appeared in the shortcut list") from None
    await option.click()
    await _poll_state(
        lambda: owner.locator(".cez-multiselect__placeholder").count(),
        lambda count: count == 0,
    )
    await _close_overlays(page)
    await _snap(rec, page, "11-shortcut-picked")

    shown = " ".join((await owner.inner_text()).split())
    placeholder_left = await owner.locator(".cez-multiselect__placeholder").count()
    if placeholder_left or not re.search(rf"\b{re.escape(request.shortcut)}\b", shown):
        raise StepFailed(f"9/19: shortcut multiselect shows {shown!r}, expected {request.shortcut!r}")
    _log("9/19", f"shortcut multiselect now has {request.shortcut!r} selected", rec)
    return request.shortcut


async def _fill_quantity(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> str:
    """Step 10: type the amount of the ingredient (grams) into ``Ilość``."""
    quantity = f"{request.quantity:g}"
    _log("10/19", f"typing quantity {quantity}", rec)
    field = page.locator(f'[id="{QUANTITY_ID}"]')
    try:
        await field.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed("10/19: the Ilość field never rendered") from None
    await field.fill(quantity)
    await field.press("Tab")
    typed = (await field.input_value()).strip()
    if typed != quantity:
        raise StepFailed(f"10/19: Ilość holds {typed!r}, expected {quantity!r}")
    await _snap(rec, page, "12-quantity-typed")
    return typed


async def _check_narcotic(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> bool:
    """Step 12: tick "Substancje odurzające i psychotropowe"."""
    if not request.narcotic:
        _log("12/19", "controlled-substance checkbox not requested", rec)
        return False
    _log("12/19", f"checking {NARCOTIC_LABEL!r}", rec)
    checked, _index = await _select_checkbox(page, 3, NARCOTIC_LABEL, rec, step="12/19")
    return checked


async def _fill_total_dose(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> str:
    """Step 13: total active substance (quantity [g] * 1000) and its unit."""
    value = f"{request.quantity * 1000:g}"
    _log("13/19", f"typing total dose {value} and picking {TOTAL_DOSE_UNIT!r}", rec)
    field = page.locator(f'[id="{TOTAL_DOSE_ID}"]')
    try:
        await field.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(
            "13/19: 'Łączna dawka substancji czynnej (liczbowo)' never appeared"
        ) from None
    await field.fill(value)
    await field.press("Tab")
    typed = (await field.input_value()).strip()
    # The numeric widget re-formats with a (non-breaking) thousands separator,
    # so compare digit sequences: "15000" comes back as "15\u00a0000".
    if re.sub(r"\D", "", typed) != re.sub(r"\D", "", value):
        raise StepFailed(f"13/19: total dose holds {typed!r}, expected {value!r}")

    unit = await _select_dropdown(
        page,
        TOTAL_DOSE_UNIT,
        rec,
        input_id=TOTAL_DOSE_UNIT_ID,
        step="13/19",
        snap_prefix="14-total-dose-unit",
    )
    words = ""
    words_field = page.locator(f'[id="{TOTAL_DOSE_WORDS_ID}"]')
    if await words_field.count():
        words = (await words_field.input_value()).strip()
    typed = typed.replace("\u00a0", " ")
    _log("13/19", f"total dose {typed} {unit} (written out: {words or 'not filled'})", rec)
    await _snap(rec, page, "15-total-dose")
    return f"{typed} {unit}"


async def _fill_dosing_text(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> str:
    """Step 15: the Polish sentence in "Opis słowny dawkowania"."""
    text = dosing_description(request.dose, request.frequency, vapor=request.vapor)
    _log("15/19", f"typing dosing description {text!r}", rec)
    field = page.locator(f'[id="{DOSING_TEXT_ID}"]')
    if not await field.count():
        host = page.locator("cez-textarea").filter(has_text="Opis słowny dawkowania").first
        field = host.locator("textarea").first
    try:
        await field.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed("15/19: 'Opis słowny dawkowania' never rendered") from None
    await field.fill(text)
    await field.press("Tab")
    typed = (await field.input_value()).strip()
    if typed != text:
        raise StepFailed(f"15/19: dosing description holds {typed!r}, expected {text!r}")
    await _snap(rec, page, "16-dosing-description")
    return typed


async def _accept_issue_warning(page: Page, rec: Recorder | None) -> bool:
    """Accept the "ten składnik nie istnieje" popup by clicking "Tak"."""
    dialog = page.locator(DIALOG_SELECTOR).locator("visible=true").first
    try:
        await dialog.wait_for(state="visible", timeout=20_000)
    except PlaywrightTimeout:
        return False

    text = " ".join((await dialog.inner_text()).split())[:400]
    _log("19/19", f"popup: {text!r}", rec)
    await _snap(rec, page, "19b-warning")

    yes = dialog.get_by_role("button", name=ISSUE_WARNING_ACCEPT, exact=True).first
    if not await yes.count():
        yes = dialog.locator("button").filter(
            has_text=re.compile(rf"^\s*{re.escape(ISSUE_WARNING_ACCEPT)}\s*$")
        ).first
    if not await yes.count():
        raise StepFailed(f"19/19: warning popup has no {ISSUE_WARNING_ACCEPT!r} button: {text}")
    await yes.click()
    await _poll_state(
        lambda: dialog.count(),
        lambda count: count == 0,
        timeout_ms=5_000,
    )
    return True


async def _issue_prescription(page: Page, rec: Recorder | None) -> str:
    """Steps 18-19: settle, click "Wystaw receptę", accept the ingredient warning."""
    _log("18/19", f'form is complete -- clicking "{ISSUE_BUTTON}"', rec)
    button = page.get_by_role("button", name=ISSUE_BUTTON, exact=True).first
    try:
        await button.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(f'18/19: "{ISSUE_BUTTON}" never appeared') from None
    try:
        await button.click()
    except PlaywrightError as error:
        raise OutcomeUnknown(
            "18/19: kliknięcie Wystaw nie dało jednoznacznego wyniku. "
            "Sprawdź recepty w gabinecie przed ponowieniem."
        ) from error
    await _snap(rec, page, "19-issue-clicked", force=True)

    try:
        accepted = await _accept_issue_warning(page, rec)
        _log(
            "19/19",
            f"warning accepted ({ISSUE_WARNING_ACCEPT!r})" if accepted else "no warning dialog appeared",
            rec,
        )
        await page.wait_for_url("**/rp/lista*", timeout=STEP_TIMEOUT_MS)
    except (StepFailed, PlaywrightError) as error:
        await _snap(rec, page, "20-outcome-unknown", force=True)
        raise OutcomeUnknown(
            "18/19: kliknięto Wystaw, ale gabinet nie potwierdził recepty na liście. "
            "Sprawdź wynik ręcznie przed kolejnym wystawieniem."
        ) from error
    await _snap(rec, page, "20-issued", force=True)
    return page.url


def _visible_dialogs(page: Page) -> Locator:
    """Visible modal popups in stacking order -- the last one is on top."""
    return page.locator(MODAL_DIALOG).locator("visible=true")


async def signing_pending(page: Page) -> bool:
    """True while the e-ZLA password popup is still open (signature not finished).

    The issuer uses this to know that navigating away (or closing the window)
    now would throw away prescriptions the doctor has not signed yet.
    """
    if page.is_closed():
        return False
    try:
        dialogs = _visible_dialogs(page)
        for index in range(await dialogs.count() - 1, -1, -1):
            if SIGN_EZLA_HEADER in await dialogs.nth(index).inner_text():
                return True
    except PlaywrightError as error:
        logger.debug("signature probe skipped: %s", error)
    return False


async def _wait_for_dialog(page: Page, marker: str, step: str) -> Locator:
    """Wait for a visible popup containing ``marker`` and return the topmost.

    Both signing popups stay mounted while the next one opens (the method popup
    sits behind the password popup), so the search runs top-down and never
    returns a covered dialog -- clicking a button there would do nothing.
    """
    deadline = time.monotonic() + STEP_TIMEOUT_MS / 1000
    while True:
        try:
            dialogs = _visible_dialogs(page)
            count = await dialogs.count()
            if count:
                dialog = dialogs.nth(count - 1)
                if marker in await dialog.inner_text():
                    return dialog
        except PlaywrightError as error:
            logger.debug("dialog probe skipped: %s", error)
        if time.monotonic() >= deadline:
            raise StepFailed(f"{step}: no popup containing {marker!r} on {page.url}") from None
        await asyncio.sleep(0.2)


_SIGN_FANFARE_JS = r"""
() => {
  // A short, self-removing fanfare: "your turn, sign".  It is one detached
  // overlay div with pointer-events:none, so typing the password and closing the
  // popup keep working exactly as in a normal gabinet window; nothing is applied
  // to gabinet's own elements and the whole overlay deletes itself.
  const old = document.getElementById('aspot-fanfare');
  if (old) old.remove();
  const colors = ['#16a34a', '#22c55e', '#facc15', '#38bdf8', '#f97316', '#e879f9'];
  const confetti = [];
  for (let i = 0; i < 60; i += 1) {
    confetti.push(
      '<span style="left:' + (Math.random() * 100).toFixed(1) + 'vw;'
      + 'width:' + (6 + Math.random() * 7).toFixed(1) + 'px;'
      + 'height:' + (10 + Math.random() * 10).toFixed(1) + 'px;'
      + 'background:' + colors[i % colors.length] + ';'
      + 'animation-delay:' + (Math.random() * 0.8).toFixed(2) + 's;'
      + 'animation-duration:' + (1.8 + Math.random() * 1.5).toFixed(2) + 's;'
      + '--dx:' + (Math.random() * 24 - 12).toFixed(1) + 'vw"></span>'
    );
  }
  const box = document.createElement('div');
  box.id = 'aspot-fanfare';
  box.setAttribute('aria-hidden', 'true');
  box.style.cssText =
    'position:fixed;inset:0;z-index:2147483647;pointer-events:none;overflow:hidden;';
  box.innerHTML =
    '<style>'
    + '#aspot-fanfare span{position:absolute;top:-14vh;border-radius:2px;opacity:0;'
    + 'animation-name:aspot-fall;animation-timing-function:cubic-bezier(.25,.6,.4,1);'
    + 'animation-fill-mode:forwards}'
    + '@keyframes aspot-fall{0%{opacity:0;transform:translate3d(0,0,0) rotate(0deg)}'
    + '10%{opacity:1}100%{opacity:.85;transform:translate3d(var(--dx,0),118vh,0) rotate(720deg)}}'
    + '#aspot-fanfare .banner{position:absolute;left:50%;top:16%;opacity:0;'
    + 'transform:translate(-50%,-50%) scale(.85);padding:20px 32px;border-radius:18px;'
    + 'background:rgba(22,163,74,.96);color:#fff;text-align:center;'
    + 'font:700 30px/1.2 system-ui,-apple-system,"Segoe UI",sans-serif;'
    + 'box-shadow:0 24px 60px rgba(15,23,42,.35);'
    + 'animation:aspot-banner 3.4s ease-out forwards}'
    + '#aspot-fanfare .banner small{display:block;margin-top:6px;opacity:.94;'
    + 'font:500 16px/1.3 system-ui,-apple-system,"Segoe UI",sans-serif}'
    + '@keyframes aspot-banner{0%{opacity:0;transform:translate(-50%,-50%) scale(.85)}'
    + '14%{opacity:1;transform:translate(-50%,-50%) scale(1.03)}'
    + '22%{transform:translate(-50%,-50%) scale(1)}80%{opacity:1}'
    + '100%{opacity:0;transform:translate(-50%,-72%) scale(1)}}'
    + '</style>'
    + '<div class="banner">Podpisz e-ZLA'
    + '<small>recepty wystawione — dokończ podpis w tym oknie</small></div>'
    + confetti.join('');
  document.body.appendChild(box);
  // Never leave anything behind in the doctor's page.
  setTimeout(() => box.remove(), 6000);
  return 'played';
}
"""


async def sign_and_send_all(page: Page, recorder: Recorder | None = None) -> str:
    """Steps 20-21: hand the whole basket to signing, then stop for the doctor.

    Issuing only *creates* the prescriptions; they leave gabinet once they are
    signed with the e-ZLA certificate.  That signature needs the certificate's
    password, which only the doctor knows, so this walks up to the password
    popup, plays a short fanfare there, raises the window and returns.  The
    caller parks the browser on it -- closing the page here would throw the
    pending signature away.
    """
    _log("20/21", f"whole basket is on {page.url}", recorder)
    with suppress(PlaywrightTimeout):
        await page.wait_for_url("**/rp/lista*", timeout=STEP_TIMEOUT_MS)
    await _snap(recorder, page, "21-lista", force=True)

    _log("20/21", f'clicking "{SIGN_ALL_BUTTON}"', recorder)
    button = page.get_by_role("button", name=SIGN_ALL_BUTTON, exact=True).first
    try:
        await button.wait_for(state="visible", timeout=STEP_TIMEOUT_MS)
    except PlaywrightTimeout:
        raise StepFailed(
            f'20/21: "{SIGN_ALL_BUTTON}" never appeared on {page.url}'
        ) from None
    await button.click()

    method = await _wait_for_dialog(page, SIGN_EZLA_BUTTON, "20/21")
    await _snap(recorder, page, "21a-sign-method")
    _log("20/21", f'popup "Podpis recept" -- clicking "{SIGN_EZLA_BUTTON}"', recorder)
    await method.get_by_role("button", name=SIGN_EZLA_BUTTON, exact=True).first.click()

    password = await _wait_for_dialog(page, SIGN_EZLA_HEADER, "21/21")
    _log("21/21", f"popup: {' '.join((await password.inner_text()).split())[:200]!r}", recorder)
    with suppress(PlaywrightError):
        await page.bring_to_front()
    fanfare = await page.evaluate(_SIGN_FANFARE_JS)
    _log("21/21", f"fanfare {fanfare}; the doctor signs now", recorder)
    await _snap(recorder, page, "21-awaiting-signature", force=True)
    return page.url


async def _configure_form(
    page: Page, rec: Recorder | None, request: PrescriptionRequest
) -> PrescriptionForm:
    """Steps 5-12: Recepturowy, Rpw, Wpisz ręcznie and the whole ingredient row."""
    await page.evaluate(_HELPERS_JS)
    radio = await _select_radio(page, RADIO_LABEL, rec)
    kind = await _select_dropdown(page, PRESCRIPTION_KIND, rec)
    checked, checkbox_index = await _select_checkbox(page, CHECKBOX_INDEX, CHECKBOX_LABEL, rec)

    await _fill_ingredient(page, request, rec)
    shortcut = await _select_shortcut(page, request, rec)
    quantity = await _fill_quantity(page, request, rec)
    unit = await _select_dropdown(
        page, request.unit, rec, input_id=UNIT_ID, step="11/19", snap_prefix="13-unit"
    )
    narcotic = await _check_narcotic(page, request, rec)

    total_dose = await _fill_total_dose(page, request, rec)
    mf = await _select_dropdown(
        page, MF_VALUE, rec, input_id=MF_ID, step="14/19", snap_prefix="17-mf"
    )
    dosing_text = await _fill_dosing_text(page, request, rec)

    visit_type = await _select_radio(page, POZ_RADIO, rec, step="16/19")
    exam_mode = await _select_radio(page, EXAM_MODE_RADIO, rec, step="17/19")

    return PrescriptionForm(
        page=page,
        radio=radio,
        kind=kind,
        checkbox_index=checkbox_index,
        checked=checked,
        ingredient=request.ingredient_name,
        shortcut=shortcut,
        quantity=quantity,
        unit=unit,
        narcotic=narcotic,
        total_dose=total_dose,
        mf=mf,
        dosing_text=dosing_text,
        visit_type=visit_type,
        exam_mode=exam_mode,
    )


async def start_new_rpw_prescription(
    pesel: str,
    *,
    page: Page,
    recorder: Recorder | None = None,
    skip_patient: bool = False,
    request: PrescriptionRequest | None = None,
    prepare: bool = False,
    on_patient_wait: Callable[[bool], None] | None = None,
) -> PrescriptionForm:
    """Run steps 1-7 on an already authenticated ``page``.

    ``recorder`` receives a snapshot per stage, plus one on failure.
    ``on_patient_wait`` is told when step 3 stalls on missing patient address
    data (see :func:`_save_patient`).

    ``skip_patient=True`` resumes on a visit that already has its patient
    (``--resume``): steps 1-4 are skipped and /rp/nowy is opened directly, which
    keeps the write-free iteration on steps 5-7 fast.
    """
    pesel = validate_pesel(pesel)
    request = request or PrescriptionRequest()
    try:
        if skip_patient:
            # Resume must never silently issue for an unrelated open visit.
            await page.goto(START_URL, wait_until="commit", timeout=STEP_TIMEOUT_MS)
            if await _visit_state(page) != "edit":
                raise StepFailed("resume: no existing patient visit to verify")
            attached = (await page.locator(PESEL_SELECTOR).input_value()).strip()
            if attached != pesel:
                raise StepFailed("resume: open visit belongs to another patient")
            _log("1-4/19", f"resume: opening {RP_NEW_URL} directly (patient verified)", recorder)
            await page.goto(RP_NEW_URL, wait_until="domcontentloaded", timeout=STEP_TIMEOUT_MS)
            if "/rp/nowy" not in page.url:
                raise StepFailed(
                    f"resume: {RP_NEW_URL} redirected to {page.url}; "
                    "the open visit has no patient -- run without --resume"
                )
            await _wait_form_ready(page, recorder)
            await _snap(recorder, page, "04-rp-nowy")
        else:
            await _snap(recorder, page, "01-start")
            at_form = await _fill_patient(page, pesel, recorder, on_patient_wait)
            if not at_form:
                await _open_prescription_form(page, recorder)
        form = await _configure_form(page, recorder, request)
        if prepare:
            _log("18/19", "--prepare: stopping before 'Wystaw receptę'", recorder)
            return form
        form.issued_url = await _issue_prescription(page, recorder)
        form.issued = form.issued_url is not None
        return form
    except Exception:
        await _snap(recorder, page, "99-failure", force=True)
        raise


async def _issue_one(page: Page, request: PrescriptionRequest, rec: Recorder | None) -> PrescriptionForm:
    """Steps 5-19 on a page that already shows a fresh /rp/nowy form."""
    form = await _configure_form(page, rec, request)
    form.issued_url = await _issue_prescription(page, rec)
    form.issued = form.issued_url is not None
    return form


async def issue_basket(
    pesel: str,
    items: Sequence[PrescriptionRequest],
    *,
    page: Page,
    recorder: Recorder | None = None,
    on_item: Callable[[int, int, PrescriptionForm], None] | None = None,
    on_patient_wait: Callable[[bool], None] | None = None,
) -> list[PrescriptionForm]:
    """Issue every basket line sequentially on one session.

    The expensive part (ending the open visit, entering the patient, opening the
    long /rp/nowy form) happens **once**; afterwards only the form itself repeats
    per line: a successful issuance lands on /rp/lista, where "Nowa recepta"
    opens the next /rp/nowy.
    """
    requests = list(items)
    if not requests:
        raise ValueError("empty basket")
    total = len(requests)

    await _snap(recorder, page, "01-start")
    at_form = await _fill_patient(page, pesel, recorder, on_patient_wait)
    if not at_form:
        await _open_prescription_form(page, recorder)

    forms: list[PrescriptionForm] = []
    for index, request in enumerate(requests):
        if index > 0:
            await _open_next_prescription(page, recorder)
        form = await _issue_one(page, request, recorder)
        forms.append(form)
        _log(f"{index + 1}/{total}", f"issued on {form.issued_url}", recorder)
        if on_item is not None:
            on_item(index + 1, total, form)
    return forms


async def _hold_browser(page: Page, recorder: Recorder, reason: str = "--keep-open") -> None:
    """Block forever so the page can be used by hand (``--keep-open``/``--sign-all``)."""
    print(
        f"\nHolding the browser open on {page.url} ({reason})\n"
        f"  artifacts: {recorder.path}\n"
        "  The page stays live; Ctrl+C to close.",
        flush=True,
    )
    recorder.note(f"holding the browser open ({reason})")
    await asyncio.Event().wait()


async def _run(
    pesel: str,
    *,
    resume: bool,
    request: PrescriptionRequest,
    keep_open: bool = False,
    prepare: bool = False,
    sign_all: bool = False,
    basket: list[PrescriptionRequest] | None = None,
    trace: bool = False,
) -> None:
    recorder = Recorder("automation", heavy=trace)
    recorder.start_capture()
    print(f"artifacts: {recorder.path}", flush=True)
    recorder.note(
        f"resume={resume} basket={len(basket) if basket else 1} sign_all={sign_all}"
    )
    _log("0/19", "launching Firefox with the saved session", recorder)
    try:
        # allow_logged_out: when the saved session expired, the doctor logs in in
        # the window instead of the run dying with "session has expired".
        async with open_session(allow_logged_out=True) as gabinet:
            _log("0/19", "browser ready", recorder)
            if await gabinet.ensure_logged_in():
                _log("0/19", "the doctor logged in; continuing", recorder)
            if basket:
                _log("0/19", f"basket of {len(basket)} item(s)", recorder)
                forms = await issue_basket(
                    pesel,
                    basket,
                    page=gabinet.page,
                    recorder=recorder,
                )
                for index, issued in enumerate(forms, start=1):
                    print(
                        f"  #{index} {issued.quantity} {issued.unit} "
                        f"{issued.ingredient.split(',')[0]} -> {issued.issued_url}",
                        flush=True,
                    )
                page = forms[-1].page if forms else gabinet.page
                if sign_all:
                    # Signing needs the doctor's certificate password: hand the
                    # window over and keep it open instead of closing on it.
                    await sign_and_send_all(page, recorder)
                    keep_open = True
            else:
                form = await start_new_rpw_prescription(
                    pesel,
                    page=gabinet.page,
                    recorder=recorder,
                    skip_patient=resume,
                    request=request,
                    prepare=prepare,
                )
                print(
                    f"\nReady: prescription form configured at {form.page.url}\n"
                    f"  radio={form.radio}  kind={form.kind}  wpisz-recznie={form.checked}\n"
                    f"  ingredient={form.ingredient!r}  shortcut={form.shortcut!r}\n"
                    f"  ilość={form.quantity}  jednostka={form.unit!r}  "
                    f"odurzające={form.narcotic}\n"
                    f"  łączna dawka={form.total_dose!r}  m.f.={form.mf!r}\n"
                    f"  dawkowanie={form.dosing_text!r}\n"
                    f"  świadczenie={form.visit_type!r}  tryb badania={form.exam_mode!r}\n"
                    f"  wystawiono={form.issued}  url={form.issued_url or '-'}",
                    flush=True,
                )
                page = form.page
            if keep_open:
                await _hold_browser(page, recorder)
            else:
                await asyncio.to_thread(input, "\nPress Enter to close the browser... ")
    finally:
        recorder.note("run finished")
        recorder.stop_capture()


def _parser() -> argparse.ArgumentParser:
    """The dev/diagnostics entry point: what to do, never a stored PESEL."""
    parser = argparse.ArgumentParser(
        prog="automation.py",
        description="Drive gabinet.gov.pl for one patient (dev + diagnostics tool).",
        epilog=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--pesel", help="patient PESEL, 11 digits (or 'pesel' in --basket)")
    parser.add_argument("--basket", help="JSON: {pesel, items:[...]} or a bare items array")
    parser.add_argument("--resume", action="store_true", help="skip steps 1-4 (patient already saved)")
    parser.add_argument("--prepare", action="store_true", help='stop before "Wystaw receptę"')
    parser.add_argument("--sign-all", action="store_true", help="run steps 20-21, then hold for the doctor")
    parser.add_argument("--keep-open", action="store_true", help="hold the window open at the end")
    parser.add_argument("--trace", action="store_true", help="snapshot every step (not just failures)")
    return parser


def _load_basket(path: str, pesel: str | None) -> tuple[str, list[PrescriptionRequest]]:
    """Read ``--basket``: either the panel's payload or a bare items array."""
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except OSError as error:
        raise SystemExit(f"error: cannot read {path} ({error})") from None
    except ValueError as error:
        raise SystemExit(f"error: {path} is not JSON ({error})") from None

    if isinstance(payload, list):  # bare items array
        payload = {"items": payload}
    if not isinstance(payload, dict):
        raise SystemExit(f"error: {path} must hold an object or an array of items")
    if pesel and payload.get("pesel") not in (None, "", pesel):
        raise SystemExit(f"error: --pesel {pesel} disagrees with {path} ({payload['pesel']})")
    payload = {**payload, "pesel": pesel or payload.get("pesel")}
    if not payload["pesel"]:
        raise SystemExit(f"error: no PESEL in {path} -- pass --pesel <11 digits>")
    try:
        return requests_from_payload(payload)
    except PayloadError as error:
        raise SystemExit(f"error: {error}") from None


def main() -> None:
    args = _parser().parse_args()
    configure_logging()
    if args.basket and (args.resume or args.prepare):
        raise SystemExit("error: --basket cannot be combined with --resume or --prepare")
    if args.sign_all and not args.basket:
        raise SystemExit("error: --sign-all requires --basket")

    basket: list[PrescriptionRequest] | None = None
    if args.basket:
        pesel, requests = _load_basket(args.basket, args.pesel)
        basket = list(requests)
        request = basket[0]
    else:
        if not args.pesel:
            raise SystemExit(
                "error: no PESEL given -- pass --pesel <11 digits> "
                "(or a --basket file that carries one)"
            )
        try:
            pesel = validate_pesel(args.pesel)
        except ValueError as error:
            raise SystemExit(f"error: {error}") from None
        request = PrescriptionRequest()
    try:
        asyncio.run(
            _run(
                pesel,
                resume=args.resume,
                request=request,
                keep_open=args.keep_open,
                prepare=args.prepare,
                sign_all=args.sign_all,
                basket=basket,
                trace=args.trace,
            )
        )
    except StepFailed as error:
        print(f"\nStopped: {error}", flush=True)
        raise SystemExit(1) from error
    except KeyboardInterrupt:
        print("\nInterrupted.", flush=True)
        raise SystemExit(130) from None


if __name__ == "__main__":
    main()
