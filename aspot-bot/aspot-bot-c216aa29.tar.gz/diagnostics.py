"""Run artifacts for the gabinet automation: screenshots, shadow-DOM dumps, probes.

gabinet's forms live in open shadow roots and every widget is a CEZ component, so
when a step fails the console error says almost nothing about *why*.  This module
writes, for each snapshot: a PNG, the full DOM **with shadow roots inlined**, and
a JSON probe of every radio/checkbox/dropdown widget (class, text, checked state,
label text, geometry).

Artifacts land next to the saved session::

    $XDG_STATE_HOME/aspot-bot/runs/<YYYYmmdd-HHMMSS>-<label>/

so inspecting a failed run is just ``ls`` + ``cat widgets.json``.
"""

from __future__ import annotations

import datetime
import json
import logging
import tempfile
from contextlib import suppress
from pathlib import Path
from typing import Any

from playwright.async_api import Page

from browser import state_dir

# Light DOM plus one HTML file per open shadow root: serialising shadow trees
# inside a <template> is unreliable in Firefox (the content is dropped), so each
# root is dumped separately and the light DOM keeps a plain outerHTML.
_DOM_JS = """
() => {
  const shadows = [];
  const walk = (root, path) => {
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) {
        const host = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '');
        shadows.push({host, path: path || "document", html: el.shadowRoot.innerHTML});
        walk(el.shadowRoot, path + "/" + host);
      }
    }
  };
  walk(document, "");
  return {light: document.documentElement.outerHTML, shadows};
}
"""

# Every widget that matters for the prescription form, with the text that
# identifies it and the state that proves the click landed.
_WIDGETS_JS = """
() => {
  const seen = [];
  const walk = (root) => {
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) walk(el.shadowRoot);
      seen.push(el);
    }
  };
  walk(document);
  const visible = (el) => {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== 'hidden';
  };
  const widgets = [];
  for (const el of seen) {
    const cls = typeof el.className === 'string' ? el.className : '';
    const isWidget = /cez-(radiobutton|checkbox|dropdown)/.test(cls)
      || el.matches('input[type=radio],input[type=checkbox]');
    if (!isWidget) continue;
    const label = el.closest('label');
    widgets.push({
      tag: el.tagName.toLowerCase(),
      id: el.id || null,
      cls: cls.trim(),
      text: (el.innerText || '').trim().slice(0, 120),
      ariaChecked: el.getAttribute('aria-checked'),
      ariaDisabled: el.getAttribute('aria-disabled'),
      checked: typeof el.checked === 'boolean' ? el.checked : null,
      disabled: typeof el.disabled === 'boolean' ? el.disabled : null,
      visible: visible(el),
      labelText: label ? (label.innerText || '').trim().slice(0, 160) : null,
      parentText: el.parentElement ? (el.parentElement.innerText || '').trim().slice(0, 200) : null,
    });
  }
  const hosts = [];
  for (const el of seen) {
    if (el.shadowRoot) {
      hosts.push({
        host: el.tagName.toLowerCase() + (el.id ? '#' + el.id : ''),
        htmlLength: el.shadowRoot.innerHTML.length,
      });
    }
  }
  return {
    url: location.href,
    title: document.title,
    shadowHosts: hosts,
    widgets,
  };
}
"""


def runs_dir() -> Path:
    """Where run artifacts are written (next to the browser session)."""
    return state_dir() / "runs"


def configure_logging(level: int = logging.INFO) -> None:
    """One log format for every entry point (the panel's ``app.log`` included).

    Without this the root logger has no handler, so ``logger.info`` -- the
    issuer's whole state machine -- is silently dropped and only ``print`` output
    survives in the doctor's log file.
    """
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


class _RecorderHandler(logging.Handler):
    """Mirrors log records into a :class:`Recorder`'s ``run.log``."""

    def __init__(self, recorder: Recorder) -> None:
        super().__init__()
        self._recorder = recorder

    def emit(self, record: logging.LogRecord) -> None:
        with suppress(Exception):  # logging must never break a run
            self._recorder.note(f"{record.name}: {record.getMessage()}")


class Recorder:
    """Collects artifacts for one automation run into its own directory."""

    def __init__(self, label: str = "run", root: Path | None = None, *, heavy: bool = False) -> None:
        stamp = datetime.datetime.now(datetime.UTC).astimezone().strftime("%Y%m%d-%H%M%S")
        parent = root or runs_dir()
        parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        # Never reuse a directory for two runs that begin within one second.
        self.dir = Path(tempfile.mkdtemp(prefix=f"{stamp}-{label}-", dir=parent))
        self._count = 0
        self._handler: logging.Handler | None = None
        self.heavy = heavy
        self.note(f"run started ({label}, artifacts={'full' if heavy else 'failures-only'})")

    @property
    def path(self) -> Path:
        return self.dir

    def note(self, message: str) -> None:
        """Append a timestamped line to ``run.log``."""
        stamp = datetime.datetime.now(datetime.UTC).astimezone().strftime("%H:%M:%S")
        try:
            with (self.dir / "run.log").open("a", encoding="utf-8") as handle:
                handle.write(f"{stamp} {message}\n")
        except OSError:
            pass  # diagnostics must never mask a prescription failure

    def start_capture(self, level: int = logging.INFO) -> None:
        """Also copy every log line into ``run.log`` until :meth:`stop_capture`.

        This is what makes a failed basket self-explanatory after the fact: the
        issuer's state transitions end up next to the screenshots instead of only
        on the doctor's (ephemeral) terminal.
        """
        if self._handler is not None:
            return
        handler = _RecorderHandler(self)
        handler.setLevel(level)
        root = logging.getLogger()
        if root.level == logging.NOTSET or root.level > level:
            root.setLevel(level)
        root.addHandler(handler)
        self._handler = handler

    def stop_capture(self) -> None:
        """Detach the handler from :meth:`start_capture` (no-op when not attached)."""
        if self._handler is not None:
            logging.getLogger().removeHandler(self._handler)
            self._handler = None

    async def snap(self, page: Page, stage: str, *, force: bool = False) -> None:
        """Save a screenshot + DOM dump + widget probe under ``<n>-<stage>``.

        Light mode (the default) only writes when ``force=True`` (i.e. on
        failures and the final state); full-page screenshots plus a 500 KB
        shadow-DOM dump per step cost real seconds on the /rp/nowy form.
        """
        if not (self.heavy or force):
            return
        self._count += 1
        prefix = f"{self._count:02d}-{stage.replace(' ', '-').replace('/', '-')}"
        try:
            await page.screenshot(
                path=str(self.dir / f"{prefix}.png"), full_page=True, timeout=20_000
            )
        except Exception as error:  # noqa: BLE001 - artifacts are best effort
            self.note(f"{prefix}: screenshot failed: {error}")
        try:
            dom = await page.evaluate(_DOM_JS)
            (self.dir / f"{prefix}.html").write_text(dom["light"], encoding="utf-8")
            for index, shadow in enumerate(dom["shadows"]):
                host = str(shadow["host"]).replace("#", "-").replace(".", "-")
                (self.dir / f"{prefix}.shadow{index}-{host}.html").write_text(
                    shadow["html"], encoding="utf-8"
                )
            self.note(f"{prefix}: {len(dom['shadows'])} shadow roots dumped")
        except Exception as error:  # noqa: BLE001 - artifacts are best effort
            self.note(f"{prefix}: dom dump failed: {error}")
        try:
            probe: dict[str, Any] = await page.evaluate(_WIDGETS_JS)
            (self.dir / f"{prefix}.widgets.json").write_text(
                json.dumps(probe, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            self.note(f"{prefix}: {len(probe['widgets'])} widgets, url={probe['url']}")
        except Exception as error:  # noqa: BLE001 - artifacts are best effort
            self.note(f"{prefix}: widget probe failed: {error}")
